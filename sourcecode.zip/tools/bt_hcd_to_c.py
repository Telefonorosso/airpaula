#!/usr/bin/env python3
"""Validate Broadcom HCD command records and generate firmware C source.

No proprietary firmware is distributed with this POC. The user supplies it.
Output C is an opaque byte array; the ARM runtime verifies chip ID and HCI status.
"""
from pathlib import Path
import hashlib
import sys


def main() -> int:
    if len(sys.argv) != 3:
        print('usage: bt_hcd_to_c.py BCM4345C0.hcd generated.c', file=sys.stderr)
        return 2
    inp, out = map(Path, sys.argv[1:])
    if inp.name != 'BCM4345C0.hcd':
        raise SystemExit('Expected filename BCM4345C0.hcd for Pi 3A+ (refuse other chip firmware)')
    data = inp.read_bytes()
    if not 1000 <= len(data) <= 512 * 1024:
        raise SystemExit(f'Unexpected HCD image size: {len(data)}')
    off = 0
    count = 0
    while off < len(data):
        if len(data) - off < 3:
            raise SystemExit(f'Truncated HCD opcode at {off}')
        opcode = data[off] | (data[off + 1] << 8)
        payload_len = data[off + 2]
        if off + 3 + payload_len > len(data):
            raise SystemExit(f'Truncated HCD record at {off}, opcode=0x{opcode:04x}')
        if (opcode & 0xfc00) != 0xfc00:
            raise SystemExit(f'Unexpected non-vendor opcode at {off}: 0x{opcode:04x}')
        if opcode == 0xfc18:
            raise SystemExit('HCD attempts UART baud rate change; unsupported in POC3')
        off += 3 + payload_len
        count += 1
        if count > 8192:
            raise SystemExit('Too many HCD records')
    sha = hashlib.sha256(data).hexdigest()
    lines = [
        '/* GENERATED - do not edit. Firmware provided separately by user. */',
        '#include <stdint.h>',
        f'/* Source SHA256: {sha} */',
        f'const unsigned bt_bcm_patchram_len = {len(data)}u;',
        f'const unsigned bt_bcm_patchram_commands = {count}u;',
        'const uint8_t bt_bcm_patchram[] = {',
    ]
    for i in range(0, len(data), 16):
        lines.append('    ' + ', '.join(f'0x{b:02x}' for b in data[i:i+16]) + ',')
    lines.append('};')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text('\n'.join(lines) + '\n', encoding='ascii')
    print(f'Broadcom HCD OK: {len(data)} bytes, {count} commands, SHA256={sha}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
