/* Emu68 POC6: non-blocking H4 receive, synchronous bounded PL011 send.
 * Runs exclusively on CPU3, after the hardware-validated POC3/P4 bring-up.
 * Copyright 2026 POC contributors, SPDX-License-Identifier: MPL-2.0
 */
#include <stdint.h>
#include <stddef.h>
#include "bt_hci_shared.h"
/* Self-contained MMIO access avoids touching Emu68's reserved-register ABI. */
static inline uint32_t bt_mmio_read(uintptr_t addr){
    uint32_t v=*(volatile uint32_t*)addr;
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    return __builtin_bswap32(v);
#else
    return v;
#endif
}
static inline void bt_mmio_write(uintptr_t addr,uint32_t v){
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    v=__builtin_bswap32(v);
#endif
    *(volatile uint32_t*)addr=v;
}
#include "btstack_run_loop.h"
#include "hci_transport.h"
#include "hci.h"
#include "btstack_run_loop.h"
#include "hci_transport.h"

#define P6_UART (0xf2000000u + 0x201000u)
#define P6_DR     0x00u
#define P6_FR     0x18u
#define P6_IBRD   0x24u
#define P6_FBRD   0x28u
#define P6_CR     0x30u
#define P6_RXFE   (1u << 4)
#define P6_TXFF   (1u << 5)
#define P6_BUSY   (1u << 3)
/* PL011 DR register error flags (bit 8 through 11). */
#define P6_DR_FE  (1u << 8)
#define P6_DR_PE  (1u << 9)
#define P6_DR_BE  (1u << 10)
#define P6_DR_OE  (1u << 11)
#define P6_BUF_CAP 2048

static btstack_data_source_t ds;
static void (*receiver)(uint8_t, uint8_t *, uint16_t);
static uint8_t in_packet[P6_BUF_CAP];
static unsigned in_pos, in_expect, in_header, in_type;
static unsigned tx_pending;
static unsigned transport_errors;
/* CPU3-only counters; reported from the same polling context as H4.
 * The original aggregate transport_errors remains bit-for-bit equivalent.
 */
static uint32_t rx_uart_error_bytes, rx_uart_overrun, rx_uart_break;
static uint32_t rx_uart_parity, rx_uart_framing;
static uint32_t rx_h4_bad_type, rx_h4_overflow, rx_h4_oversize;
static uint32_t tx_fifo_timeouts, tx_busy_timeouts, tx_partial_timeouts;
static uint32_t tx_last_fail_sent, tx_last_fail_total, tx_last_fail_fr;

void bt_poc6_transport_diag_snapshot(volatile struct bt_hci_diag_shared *p){
    if (!p) return;
    p->hci_rx_uart_error_bytes=rx_uart_error_bytes;
    p->hci_rx_uart_overrun=rx_uart_overrun;
    p->hci_rx_uart_break=rx_uart_break;
    p->hci_rx_uart_parity=rx_uart_parity;
    p->hci_rx_uart_framing=rx_uart_framing;
    p->hci_rx_h4_bad_type=rx_h4_bad_type;
    p->hci_rx_h4_overflow=rx_h4_overflow;
    p->hci_rx_h4_oversize=rx_h4_oversize;
    p->hci_tx_fifo_timeouts=tx_fifo_timeouts;
    p->hci_tx_busy_timeouts=tx_busy_timeouts;
    p->hci_tx_partial_timeouts=tx_partial_timeouts;
    p->hci_tx_last_fail_sent=tx_last_fail_sent;
    p->hci_tx_last_fail_total=tx_last_fail_total;
    p->hci_tx_last_fail_fr=tx_last_fail_fr;
    /* Register snapshots are read-only; no UART state is changed. */
    p->hci_pl011_cr_live=bt_mmio_read(P6_UART+P6_CR);
    p->hci_pl011_fr_live=bt_mmio_read(P6_UART+P6_FR);
    p->hci_pl011_ibrd_live=bt_mmio_read(P6_UART+P6_IBRD);
    p->hci_pl011_fbrd_live=bt_mmio_read(P6_UART+P6_FBRD);
}
static uint32_t acl_tx_packets, acl_tx_bytes, acl_rx_packets;
static uint32_t acl_completed, acl_completion_events;
/* Passive H4 traffic counters used only after the POC6 test completes. */
void bt_poc6_transport_snapshot(volatile uint32_t *tx_packets, volatile uint32_t *tx_bytes,
                                 volatile uint32_t *completed, volatile uint32_t *completion_events,
                                 volatile uint32_t *rx_packets){
    *tx_packets = acl_tx_packets;
    *tx_bytes = acl_tx_bytes;
    *completed = acl_completed;
    *completion_events = acl_completion_events;
    *rx_packets = acl_rx_packets;
}

static uint64_t tick(void){ uint64_t v; __asm__ volatile("mrs %0, CNTVCT_EL0":"=r"(v));return v; }
static uint64_t deadline_ms(uint32_t ms){uint64_t fr;__asm__ volatile("mrs %0, CNTFRQ_EL0":"=r"(fr)); return tick() + fr*ms/1000u;}
static int before(uint64_t until){return (int64_t)(tick()-until)<0;}

static void process(btstack_data_source_t *src, btstack_data_source_callback_type_t event){
    (void)src;
    if (event != DATA_SOURCE_CALLBACK_POLL) return;
    if (tx_pending){
        uint8_t sent[] = {HCI_EVENT_TRANSPORT_PACKET_SENT, 0};
        tx_pending=0;
        if(receiver)receiver(HCI_EVENT_PACKET,sent,sizeof(sent));
    }
    for(unsigned budget=0; budget<2048; ++budget){
        if(bt_mmio_read(P6_UART+P6_FR)&P6_RXFE)break;
        uint32_t w=bt_mmio_read(P6_UART+P6_DR);
        if(w&0xf00u){
            transport_errors++;
            rx_uart_error_bytes++;
            if(w&P6_DR_OE) rx_uart_overrun++;
            if(w&P6_DR_BE) rx_uart_break++;
            if(w&P6_DR_PE) rx_uart_parity++;
            if(w&P6_DR_FE) rx_uart_framing++;
            in_pos=in_expect=in_header=0;
            continue;
        }
        uint8_t b=(uint8_t)w;
        if(!in_header){
            if(b!=HCI_EVENT_PACKET && b!=HCI_ACL_DATA_PACKET){ transport_errors++; rx_h4_bad_type++; continue; }
            in_type=b; in_header=1; in_pos=0; in_expect=(b==HCI_EVENT_PACKET)?2u:4u;
            continue;
        }
        if(in_pos>=P6_BUF_CAP){transport_errors++;rx_h4_overflow++;in_header=in_pos=in_expect=0;continue;}
        in_packet[in_pos++]=b;
        if(in_pos==in_expect){
            if((in_type==HCI_EVENT_PACKET && in_expect==2u) ||
               (in_type==HCI_ACL_DATA_PACKET && in_expect==4u)){
                unsigned len= in_type==HCI_EVENT_PACKET ? in_packet[1] :
                        ((unsigned)in_packet[2] | ((unsigned)in_packet[3]<<8));
                if(len>P6_BUF_CAP-in_expect){transport_errors++;rx_h4_oversize++;in_header=in_pos=in_expect=0;continue;}
                in_expect+=len;
                if(len) continue;
            }
            if(in_type == HCI_ACL_DATA_PACKET) acl_rx_packets++;
            if(in_type == HCI_EVENT_PACKET && in_pos >= 3 && in_packet[0] == 0x13u){
                /* HCI Event Number Of Completed Packets (0x13). */
                unsigned handles = in_packet[2];
                if(in_pos >= 3u + 4u * handles){
                    acl_completion_events++;
                    for(unsigned i=0;i<handles;i++){
                        unsigned off=3u+4u*i;
                        acl_completed += (unsigned)in_packet[off+2] |
                                         ((unsigned)in_packet[off+3] << 8);
                    }
                }
            }
            if(receiver)receiver((uint8_t)in_type,in_packet,(uint16_t)in_pos);
            in_header=in_pos=in_expect=0;
        }
    }
}
static void transport_init(const void *config){
    (void)config;
    /* hci_init() registers receiver BEFORE hci_power_control(ON) calls
     * transport_init(). Do not reset receiver here: doing so silently drops
     * every HCI event and prevents HCI_STATE_WORKING (POC11-B boot regression).
     * transport_close() still clears receiver during explicit teardown. */
    in_header=in_pos=in_expect=0;tx_pending=0;
    /* Per-epoch diagnostics; the previous epoch's totals have already been
     * recorded in CPU3's shared page before teardown. */
    transport_errors=0;
    rx_uart_error_bytes=rx_uart_overrun=rx_uart_break=0;
    rx_uart_parity=rx_uart_framing=0;
    rx_h4_bad_type=rx_h4_overflow=rx_h4_oversize=0;
    tx_fifo_timeouts=tx_busy_timeouts=tx_partial_timeouts=0;
    tx_last_fail_sent=tx_last_fail_total=tx_last_fail_fr=0;
    acl_tx_packets=acl_tx_bytes=acl_rx_packets=acl_completed=acl_completion_events=0;
}
static int transport_open(void){
    btstack_run_loop_set_data_source_handler(&ds,process);
    btstack_run_loop_enable_data_source_callbacks(&ds,DATA_SOURCE_CALLBACK_POLL);
    btstack_run_loop_add_data_source(&ds);return 0;
}
static int transport_close(void){
    btstack_run_loop_remove_data_source(&ds);
    receiver=NULL;tx_pending=0;in_header=in_pos=in_expect=0;
    return 0;
}
static void transport_register(void(*f)(uint8_t,uint8_t*,uint16_t)){receiver=f;}
static int transport_can_send(uint8_t type){(void)type;return !tx_pending;}
static int transport_send(uint8_t type,uint8_t*packet,int size){
    if(size<0 || size>1900 || tx_pending)return -1;
    uint64_t until=deadline_ms(300);
    uint32_t sent=0;
    for(int i=-1;i<size;i++){
        uint8_t c=i<0?type:packet[i];
        while(bt_mmio_read(P6_UART+P6_FR)&P6_TXFF){
            if(!before(until)){
                transport_errors++;
                tx_fifo_timeouts++;
                if(sent) tx_partial_timeouts++;
                tx_last_fail_sent=sent;
                tx_last_fail_total=(uint32_t)size+1u;
                tx_last_fail_fr=bt_mmio_read(P6_UART+P6_FR);
                return -1;
            }
        }
        bt_mmio_write(P6_UART+P6_DR,c);
        sent++;
    }
    while(bt_mmio_read(P6_UART+P6_FR)&P6_BUSY){
        if(!before(until)){
            transport_errors++;
            tx_busy_timeouts++;
            tx_partial_timeouts++;
            tx_last_fail_sent=sent;
            tx_last_fail_total=(uint32_t)size+1u;
            tx_last_fail_fr=bt_mmio_read(P6_UART+P6_FR);
            return -1;
        }
    }
    if(type == HCI_ACL_DATA_PACKET){
        acl_tx_packets++;
        acl_tx_bytes+=(uint32_t)size;
    }
    tx_pending=1;
    return 0;
}
static const hci_transport_t p6_transport={
    .name="Emu68 PL011 H4",.init=transport_init,.open=transport_open,
    .close=transport_close,.register_packet_handler=transport_register,
    .can_send_packet_now=transport_can_send,.send_packet=transport_send,
};
const hci_transport_t * bt_poc6_transport(void){return &p6_transport;}
unsigned bt_poc6_transport_errors(void){return transport_errors;}
/* BTstack's embedded runloop is polled rather than interrupt-driven.
 * Never sleep/wfe here: CPU3 must service HCI and A2DP timers. */
void hal_cpu_disable_irqs(void){}
void hal_cpu_enable_irqs(void){}
void hal_cpu_enable_irqs_and_sleep(void){__asm__ volatile("yield");}
uint32_t hal_time_ms(void){
    uint64_t freq;__asm__ volatile("mrs %0, CNTFRQ_EL0":"=r"(freq));
    return freq?(uint32_t)(tick()*1000u/freq):0;
}
