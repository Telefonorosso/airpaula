/* Pi 3A+ Emu68 POC6: targeted, time-limited A2DP Source SBC tone.
 * Separate from the hardware-validated HCI/firmware path. No Paula yet.
 * SPDX-License-Identifier: MPL-2.0
 */
#include <stdint.h>
#include <string.h>
#include "btstack_memory.h"
#include "btstack_event.h"
#include "btstack_run_loop.h"
#include "hci.h"
#include "hci_transport.h"
#include "gap.h"
#include "l2cap.h"
#include "classic/a2dp_source.h"
#include "classic/avdtp_source.h"
#include "classic/avdtp_util.h"
#include "classic/sdp_server.h"
#include "classic/sdp_client.h"
#include "btstack_run_loop_embedded.h"
#include "classic/btstack_sbc_bluedroid.h"
#include "classic/btstack_link_key_db_memory.h"
#include "bt_hci_shared.h"
#if defined(EMU68_BT_PAULA_POC7)
#include "paula_bt_pcm.h"
#endif

extern const hci_transport_t *bt_poc6_transport(void);
extern unsigned bt_poc6_transport_errors(void);
extern void bt_poc6_transport_diag_snapshot(volatile struct bt_hci_diag_shared *);
extern void bt_poc6_transport_snapshot(volatile uint32_t *,volatile uint32_t *,volatile uint32_t *,volatile uint32_t *,volatile uint32_t *);

static volatile struct bt_hci_diag_shared *stats;
static bd_addr_t peer;
static btstack_packet_callback_registration_t hci_callback;
static uint8_t sdp_record[180];
static uint8_t sbc_cap[] = { ((AVDTP_SBC_44100|AVDTP_SBC_48000)<<4)|AVDTP_SBC_STEREO, 0xff, 2, 45 };
static uint8_t sbc_config[4];
static uint8_t sbc_payload[900];
static btstack_sbc_encoder_bluedroid_t encoder_context;
static const btstack_sbc_encoder_t *encoder;
static uint16_t cid;
static uint8_t seid;
static unsigned pcm_rate=48000, started, ended, send_pending;
static uint32_t timestamp, sample_frames_sent, phase, tone_started_at;
static btstack_timer_source_t send_timer;
static uint32_t global_started_at;
static uint8_t finish_requested;
static unsigned live_paula;
static uint32_t send_requested_at;

/* POC9: CPU3 owns connection recovery. Amiga chord reset restarts the Pi,
 * so no A2DP state is assumed to survive it. Paired peers can nevertheless
 * need several seconds to discard their old ACL and become connectable.
 * The tested Paula/SBC producer below is deliberately left unchanged. */
enum { P9_IDLE=0, P9_WAIT=1, P9_CONNECTING=2, P9_STREAMING=3, P9_CLOSING=4 };
#define P9_INITIAL_DELAY_MS 1500u
#define P9_BACKOFF_FIRST_MS 2000u
#define P9_BACKOFF_MAX_MS 16000u
#define P9_ATTEMPT_TIMEOUT_MS 20000u
#define P9_CLOSE_TIMEOUT_MS 15000u
static uint8_t p9_state, p9_close_sent;
static uint32_t p9_due, p9_attempt_at, p9_close_at, p9_backoff;

static void p9_clear_stream(void){
    /* send_timer is installed only after STREAM_STARTED. */
    if(started) btstack_run_loop_remove_timer(&send_timer);
    started=0;
    send_pending=0;
    encoder=0;
    stats->a2dp_stream_open=0;
    stats->a2dp_stream_started=0;
}

static void p9_wait(uint8_t status){
    if(!live_paula){ ended=1; return; }
    p9_clear_stream();
    cid=0;
    stats->a2dp_reconnect_stalled=0;
    p9_state=P9_WAIT;
    p9_due=btstack_run_loop_get_time_ms()+p9_backoff;
    stats->a2dp_reconnect_delay_ms=p9_backoff;
    stats->a2dp_reconnect_last_error=status;
    stats->stop_reason=BTDIAG_STOP_A2DP_RECONNECTING;
    if(p9_backoff<P9_BACKOFF_MAX_MS){
        p9_backoff*=2u;
        if(p9_backoff>P9_BACKOFF_MAX_MS)p9_backoff=P9_BACKOFF_MAX_MS;
    }
    stats->a2dp_reconnect_state=p9_state;
}

/* If AVDTP signaling is open, first request its normal L2CAP teardown.
 * Never issue a second CREATE_CONNECTION while BTstack still owns a CID. */
static void p9_failure(uint8_t status, int signaling_may_be_open){
    if(!live_paula){ended=1;return;}
    if(p9_state!=P9_CONNECTING && p9_state!=P9_STREAMING)return;
    stats->a2dp_reconnect_failures++;
    stats->a2dp_reconnect_last_error=status;
    p9_clear_stream();
    if(signaling_may_be_open && cid){
        p9_state=P9_CLOSING;
        p9_close_sent=0;
        p9_close_at=btstack_run_loop_get_time_ms();
        stats->a2dp_reconnect_state=p9_state;
        stats->stop_reason=BTDIAG_STOP_A2DP_RECONNECTING;
    }else{
        p9_wait(status);
    }
}

/* BTstack A2DP Source also accepts an incoming AVDTP signaling channel.
 * A bonded SoundCore can initiate it before the delayed outgoing attempt.
 * Keep that session rather than issuing a competing connection request. */
static void p9_adopt_signaling(uint16_t incoming_cid){
    if(!live_paula || !incoming_cid || p9_state==P9_CLOSING ||
       p9_state==P9_STREAMING)return;
    if(p9_state==P9_WAIT || p9_state==P9_IDLE){
        p9_state=P9_CONNECTING;
        p9_attempt_at=btstack_run_loop_get_time_ms();
        stats->a2dp_reconnect_state=p9_state;
        stats->a2dp_reconnect_delay_ms=0;
    }
    /* The source application supports one target and one AVDTP session. */
    if(!cid)cid=incoming_cid;
}

static void p9_work(uint32_t now){
    if(!live_paula)return;
    if(p9_state==P9_WAIT && (int32_t)(now-p9_due)>=0){
        /* Do not allocate a second AVDTP session until the previous has
         * emitted SIGNALING_CONNECTION_RELEASED (or failed and was freed). */
        p9_state=P9_CONNECTING;
        p9_attempt_at=now;
        stats->a2dp_reconnect_attempts++;
        stats->a2dp_reconnect_state=p9_state;
        stats->a2dp_reconnect_delay_ms=0;
        uint8_t rc=a2dp_source_establish_stream(peer,&cid);
        if(rc==ERROR_CODE_COMMAND_DISALLOWED){
            /* BTstack returns 0x0c if this peer already has an active
             * incoming/outgoing AVDTP setup. Its documented behavior is
             * to complete the incoming setup. Adopt it and await events;
             * the normal 20-second watchdog handles a genuine stall. */
            avdtp_connection_t *existing=avdtp_get_connection_for_bd_addr(peer);
            if(existing){
                p9_adopt_signaling(existing->avdtp_cid);
            }else{
                stats->a2dp_last_status=rc;
                p9_failure(rc,0);
            }
        }else if(rc){
            stats->a2dp_last_status=rc;
            p9_failure(rc,0);
        }
    }else if(p9_state==P9_CONNECTING &&
             (uint32_t)(now-p9_attempt_at)>=P9_ATTEMPT_TIMEOUT_MS){
        /* No A2DP callback after an ACL collision / remote reboot. Abort
         * the existing AVDTP attempt, then retry after a bounded delay. */
        p9_failure(0xf0u,1);
        stats->a2dp_reconnect_watchdogs++;
    }
    if(p9_state==P9_CLOSING){
        if(!p9_close_sent){
            p9_close_sent=1;
            uint16_t old_cid=cid;
            uint8_t rc=old_cid ? a2dp_source_disconnect(old_cid) : ERROR_CODE_UNKNOWN_CONNECTION_IDENTIFIER;
            if(rc==ERROR_CODE_UNKNOWN_CONNECTION_IDENTIFIER){
                /* Already freed by BTstack. */
                p9_wait(stats->a2dp_reconnect_last_error);
            }else if(rc){
                stats->a2dp_reconnect_last_error=rc;
                p9_wait(rc);
            }else if(!avdtp_get_connection_for_avdtp_cid(old_cid)){
                /* BTstack's avdtp_disconnect() can finalize a pending
                 * SDP/ACL connection synchronously, emitting a failed
                 * SIGNALING_CONNECTION_ESTABLISHED rather than a RELEASED
                 * event. In this case the teardown is already finished:
                 * waiting for RELEASED would permanently stall retry. */
                p9_wait(stats->a2dp_reconnect_last_error);
            }
        }else if((uint32_t)(now-p9_close_at)>=P9_CLOSE_TIMEOUT_MS){
            /* The connection never released: do not fabricate a clean CID
             * or reset the live controller, which can corrupt BTstack. */
            stats->a2dp_reconnect_stalled=1;
        }
    }
}


/* 32-point sine at safe amplitude; no floating point or libc math. */
static const int16_t sine32[32] = {
    0, 1598, 3135, 4551, 5793, 6811, 7568, 8035,
    8192, 8035, 7568, 6811, 5793, 4551, 3135, 1598,
    0, -1598, -3135, -4551, -5793, -6811, -7568, -8035,
    -8192, -8035, -7568, -6811, -5793, -4551, -3135, -1598
};
static void synth(int16_t *buf,unsigned frames){
    uint32_t increment=(uint32_t)(((uint64_t)440u<<32)/pcm_rate);
#if defined(EMU68_BT_PAULA_POC7)
    if(live_paula){emu68_paula_bt_read_pcm(buf,frames);return;}
#endif
    for(unsigned i=0;i<frames;i++){
        int16_t s=sine32[phase>>27];phase+=increment;
        buf[2*i]=s;buf[2*i+1]=s;
    }
}
static void send_frame_group(void){
    stats->a2dp_send_attempts++;
    if(!started||!encoder||!cid||!seid){stats->a2dp_last_skip_reason=1;return;}

    unsigned frames_per_sbc=encoder->num_audio_frames(&encoder_context);
    stats->a2dp_sbc_samples_per_frame=frames_per_sbc;
    if(!frames_per_sbc||frames_per_sbc>256){
        stats->a2dp_last_skip_reason=2;return;
    }

    uint32_t now=btstack_run_loop_get_time_ms();
    uint32_t required=(uint32_t)((uint64_t)(now-tone_started_at)*pcm_rate/1000u);
    uint32_t available=required>sample_frames_sent ? required-sample_frames_sent:0;
    if(available<frames_per_sbc){stats->a2dp_last_skip_reason=4;return;}

    int media_capacity=a2dp_max_media_payload_size(cid,seid);
    stats->a2dp_last_media_mtu=media_capacity>0?(uint32_t)media_capacity:0;
    if(media_capacity<=1){stats->a2dp_last_skip_reason=3;return;}
    if((unsigned)media_capacity>sizeof(sbc_payload))media_capacity=sizeof(sbc_payload);

    /* Bluedroid's sbc_buffer_length() is ZERO until the first SBC frame has
     * actually been encoded. Probe one frame, then use its real encoded size
     * for payload packing. Do not modify BTstack itself. */
    int16_t pcm[512];
    synth(pcm,frames_per_sbc);
    /* Verify that the tone is not zero without exposing sample contents. */
    for(unsigned i=0;i<frames_per_sbc*2u;i++){
        int32_t v=pcm[i];
        uint32_t a=(uint32_t)(v<0?-v:v);
        if(a>stats->a2dp_pcm_peak)stats->a2dp_pcm_peak=a;
    }
    uint8_t encode_rc=encoder->encode_signed_16(&encoder_context,pcm,&sbc_payload[1]);
    if(encode_rc){
        stats->a2dp_last_status=encode_rc;
        stats->a2dp_last_skip_reason=6;return;
    }
    unsigned bytes_per_sbc=encoder->sbc_buffer_length(&encoder_context);
    if(bytes_per_sbc>=4u && !stats->a2dp_sbc_first4){
        stats->a2dp_sbc_first4 = ((uint32_t)sbc_payload[1]<<24) |
             ((uint32_t)sbc_payload[2]<<16) |
             ((uint32_t)sbc_payload[3]<<8) | sbc_payload[4];
    }
    stats->a2dp_sbc_bytes_per_frame=bytes_per_sbc;
    if(!bytes_per_sbc||bytes_per_sbc>255){
        stats->a2dp_last_skip_reason=2;return;
    }
    if(bytes_per_sbc>(unsigned)(media_capacity-1)){
        stats->a2dp_last_skip_reason=3;return;
    }

    unsigned count=available/frames_per_sbc;
    if(count>5)count=5; /* SBC payload header uses a four-bit count. */
    unsigned fitting=((unsigned)media_capacity-1)/bytes_per_sbc;
    if(count>fitting)count=fitting;
    if(count==0){stats->a2dp_last_skip_reason=3;return;}

    sbc_payload[0]=(uint8_t)count;
    /* First SBC frame was already encoded into sbc_payload[1]. */
    for(unsigned i=1;i<count;i++){
        synth(pcm,frames_per_sbc);
        encode_rc=encoder->encode_signed_16(&encoder_context,pcm,
                                            &sbc_payload[1+i*bytes_per_sbc]);
        if(encode_rc){
            stats->a2dp_last_status=encode_rc;
            stats->a2dp_last_skip_reason=6;return;
        }
        /* A negotiated SBC configuration produces constant-size frames. */
    }
    uint8_t rc=a2dp_source_stream_send_media_payload_rtp(cid,seid,0,timestamp,
                           sbc_payload,(uint16_t)(1+count*bytes_per_sbc));
    stats->a2dp_last_send_rc=rc;
    if(rc){stats->a2dp_last_status=rc;stats->a2dp_last_skip_reason=5;return;}
    stats->a2dp_last_skip_reason=0;
    sample_frames_sent+=count*frames_per_sbc;
    timestamp+=count*frames_per_sbc;
    stats->a2dp_packets++;
    stats->a2dp_sbc_frames+=count;
}
static void send_tick(btstack_timer_source_t *timer){
    if(!started||ended)return;
    stats->a2dp_timer_ticks++;
    btstack_run_loop_set_timer(timer,8);
    btstack_run_loop_add_timer(timer);
    uint32_t now=btstack_run_loop_get_time_ms();
    if(send_pending){
        /* A missing CAN_SEND event must not block the producer forever.
         * Retry at most once per 100 ms. AVDTP/L2CAP coalesces requests.
         */
        if((uint32_t)(now-send_requested_at)<100u)return;
        stats->a2dp_send_retries++;
    }
    send_pending=1;
    send_requested_at=now;
    stats->a2dp_send_requests++;
    a2dp_source_stream_endpoint_request_can_send_now(cid,seid);
}
static void a2dp_handler(uint8_t type,uint16_t channel,uint8_t *p,uint16_t size){
    (void)channel;(void)size;
    if(type!=HCI_EVENT_PACKET||hci_event_packet_get_type(p)!=HCI_EVENT_A2DP_META)return;
    switch(p[2]){
        case A2DP_SUBEVENT_SIGNALING_CONNECTION_ESTABLISHED: {
            bd_addr_t incoming_addr;
            a2dp_subevent_signaling_connection_established_get_bd_addr(p,incoming_addr);
            if(memcmp(incoming_addr,peer,6))break;
            uint8_t status=a2dp_subevent_signaling_connection_established_get_status(p);
            if(status){
                stats->a2dp_last_status=status;
                /* BTstack finalizes a failed signaling connection after
                 * this callback; don't tear down or retry synchronously. */
                p9_failure(status,0);
            }else{
                /* Inbound signaling is legitimate, even while P9_WAIT.
                 * Without this transition POC9 ignored the ensuing stream
                 * callbacks and repeatedly returned command disallowed. */
                p9_adopt_signaling(
                    a2dp_subevent_signaling_connection_established_get_a2dp_cid(p));
            }
            break;
        }
        case A2DP_SUBEVENT_SIGNALING_CONNECTION_RELEASED:
            if(live_paula && p9_state!=P9_WAIT){
                if(p9_state==P9_STREAMING || p9_state==P9_CONNECTING)
                    stats->a2dp_reconnect_failures++;
                p9_wait((uint8_t)stats->a2dp_last_status);
            }
            break;
        case A2DP_SUBEVENT_SIGNALING_MEDIA_CODEC_SBC_CONFIGURATION: {
            int channels=a2dp_subevent_signaling_media_codec_sbc_configuration_get_num_channels(p);
            pcm_rate=a2dp_subevent_signaling_media_codec_sbc_configuration_get_sampling_frequency(p);
            int blocks=a2dp_subevent_signaling_media_codec_sbc_configuration_get_block_length(p);
            int bands=a2dp_subevent_signaling_media_codec_sbc_configuration_get_subbands(p);
            int bitpool=a2dp_subevent_signaling_media_codec_sbc_configuration_get_max_bitpool_value(p);
            int method=a2dp_subevent_signaling_media_codec_sbc_configuration_get_allocation_method(p);
            int mode=a2dp_subevent_signaling_media_codec_sbc_configuration_get_channel_mode(p);
            if(channels!=2||blocks<=0||bands<=0||(pcm_rate!=44100&&pcm_rate!=48000)
               || (live_paula && pcm_rate!=48000)){
                stats->a2dp_last_status=0xe1;p9_failure(0xe1u,1);break;
            }
            if(bitpool>35)bitpool=35;
            if(bitpool<2){stats->a2dp_last_status=0xe3;p9_failure(0xe3u,1);break;}
            stats->a2dp_negotiated_bitpool=(uint32_t)bitpool;
            stats->a2dp_negotiated_mode=(uint32_t)mode;
            stats->a2dp_negotiated_blocks=(uint32_t)blocks;
            stats->a2dp_negotiated_subbands=(uint32_t)bands;
            encoder=btstack_sbc_encoder_bluedroid_init_instance(&encoder_context);
            encoder->configure(&encoder_context,SBC_MODE_STANDARD,blocks,bands,
                (btstack_sbc_allocation_method_t)(method-1),pcm_rate,bitpool,
                mode==AVDTP_CHANNEL_MODE_JOINT_STEREO?SBC_CHANNEL_MODE_JOINT_STEREO:
                mode==AVDTP_CHANNEL_MODE_STEREO?SBC_CHANNEL_MODE_STEREO:SBC_CHANNEL_MODE_DUAL_CHANNEL);
            stats->a2dp_sample_rate=pcm_rate;
            break;
        }
        case A2DP_SUBEVENT_STREAM_ESTABLISHED: {
            bd_addr_t incoming_addr;
            a2dp_subevent_stream_established_get_bd_addr(p,incoming_addr);
            if(memcmp(incoming_addr,peer,6))break;
            /* A spontaneous incoming stream may reach us before the
             * outgoing timer. Adopt it instead of dropping success. */
            if(live_paula && p9_state==P9_WAIT){
                p9_adopt_signaling(a2dp_subevent_stream_established_get_a2dp_cid(p));
            }
            /* A late success after watchdog-driven teardown must not start
             * Paula audio against an AVDTP connection being closed. */
            if(live_paula && p9_state!=P9_CONNECTING)break;
            uint8_t status=a2dp_subevent_stream_established_get_status(p);
            stats->a2dp_last_status=status;
            if(status){p9_failure(status,1);break;}
            cid=a2dp_subevent_stream_established_get_a2dp_cid(p);
            seid=a2dp_subevent_stream_established_get_local_seid(p);
            stats->a2dp_stream_open=1;
            status=a2dp_source_start_stream(cid,seid);
            if(status){stats->a2dp_last_status=status;p9_failure(status,1);}
            break;
        }
        case A2DP_SUBEVENT_STREAM_STARTED:
            if(live_paula && p9_state!=P9_CONNECTING)break;
            started=1;
            if(live_paula){
                p9_state=P9_STREAMING;
                p9_backoff=P9_BACKOFF_FIRST_MS;
                stats->a2dp_reconnect_state=p9_state;
                stats->a2dp_reconnect_successes++;
                stats->a2dp_reconnect_stalled=0;
            }
            tone_started_at=btstack_run_loop_get_time_ms();
            sample_frames_sent=timestamp=phase=0;
            stats->a2dp_stream_started=1;
#if defined(EMU68_BT_PAULA_POC7)
            if (live_paula) stats->stop_reason=BTDIAG_STOP_A2DP_PAULA_LIVE;
#endif
            btstack_run_loop_set_timer_handler(&send_timer,send_tick);
            btstack_run_loop_set_timer(&send_timer,8);
            btstack_run_loop_add_timer(&send_timer);
            /* Kick the first media permission immediately; the 8 ms timer
             * then paces subsequent frames. No media is pushed without
             * BTstack's CAN_SEND callback. */
            send_pending=1;
            send_requested_at=tone_started_at;
            stats->a2dp_send_requests++;
            a2dp_source_stream_endpoint_request_can_send_now(cid,seid);
            break;
        case A2DP_SUBEVENT_STREAMING_CAN_SEND_MEDIA_PACKET_NOW:
            stats->a2dp_can_send_events++;
            send_pending=0;
            send_frame_group();
            break;
        case A2DP_SUBEVENT_STREAM_RELEASED:
            p9_failure(0xf1u,1);
            break;
        default:break;
    }
}
static volatile struct bt_hci_control_shared *poc8_ctrl;
static uint32_t poc8_last_command;
static unsigned recover_requested;
/* If the user paired but has not yet copied bt_bond to config.txt,
 * carry the current Link Key across a local rebootstrap. Never shared. */
static link_key_t recover_ram_key;
static unsigned recover_ram_type, recover_ram_key_valid;

static void poc8_service_key_request(void){
    if(!poc8_ctrl)return;
    uint32_t seq=poc8_ctrl->request_seq;
    if(seq==poc8_last_command)return;
    poc8_last_command=seq;
    uint32_t cmd=poc8_ctrl->command;
    poc8_ctrl->result=0;
    poc8_ctrl->key_type=0;
    memset((void *)poc8_ctrl->link_key,0,16);
    if(cmd==BTCTRL_RECOVER && live_paula){
        /* DO NOT write completed_seq yet: the caller blocks until CPU3 has
         * reconstructed HCI and BTstack. No HCI commands on the broken link. */
        recover_requested=1;
        if(stats) stats->recover_stage=1u;
        return;
    }
    if(cmd==BTCTRL_KEY){
        link_key_t key;
        link_key_type_t type=INVALID_LINK_KEY;
        if(gap_get_link_key_for_bd_addr(peer,key,&type)){
            /* Convert key exactly as stored by BTstack: 16 opaque bytes. */
            for(unsigned i=0;i<16;i++)poc8_ctrl->link_key[i]=key[i];
            for(unsigned i=0;i<6;i++)poc8_ctrl->peer[i]=peer[i];
            poc8_ctrl->key_type=(uint32_t)type;
            poc8_ctrl->result=BTCTRL_OK;
            memset(key,0,sizeof(key));
        }else{
            poc8_ctrl->result=BTCTRL_NO_KEY;
        }
    }else{
        poc8_ctrl->result=BTCTRL_BAD_MODE;
    }
    __asm__ volatile("dsb sy" ::: "memory");
    poc8_ctrl->completed_seq=seq;
    __asm__ volatile("dsb sy" ::: "memory");
}

static void hci_handler(uint8_t type,uint16_t channel,uint8_t *p,uint16_t size){
    (void)channel;(void)size;
    if(type!=HCI_EVENT_PACKET)return;
    switch(hci_event_packet_get_type(p)){
        case BTSTACK_EVENT_STATE:
            if(btstack_event_state_get_state(p)!=HCI_STATE_WORKING)break;
            stats->a2dp_controller_working=1;
            /* The POC11-B command completes only after real HCI WORKING.
             * Playback can take longer; normal POC9 reconnection handles it. */
            if(poc8_ctrl && poc8_ctrl->command==BTCTRL_RECOVER &&
               poc8_ctrl->request_seq!=poc8_ctrl->completed_seq &&
               stats->recover_stage==3u){
                stats->recover_stage=4u;
                stats->recover_successes++;
                poc8_ctrl->result=BTCTRL_OK;
                __asm__ volatile("dsb sy" ::: "memory");
                poc8_ctrl->completed_seq=poc8_ctrl->request_seq;
                __asm__ volatile("dsb sy" ::: "memory");
            }
            {
                bd_addr_t native;
                gap_local_bd_addr(native);
                stats->bond_actual_bd_hi=((uint32_t)native[0]<<8)|native[1];
                stats->bond_actual_bd_lo=((uint32_t)native[2]<<24)|
                    ((uint32_t)native[3]<<16)|((uint32_t)native[4]<<8)|native[5];
                stats->bond_local_addr_match =
                    (stats->bd_addr_valid &&
                     stats->bond_actual_bd_hi == stats->bd_addr_hi &&
                     stats->bond_actual_bd_lo == stats->bd_addr_lo) ? 1u : 2u;
            }
            if(live_paula){
                /* Allow the remote speaker's old ACL to settle after Pi
                 * chord reset; all future reconnects are CPU3 autonomous. */
                p9_state=P9_WAIT;
                p9_due=btstack_run_loop_get_time_ms()+P9_INITIAL_DELAY_MS;
                stats->a2dp_reconnect_state=p9_state;
                stats->a2dp_reconnect_delay_ms=P9_INITIAL_DELAY_MS;
                stats->stop_reason=BTDIAG_STOP_A2DP_RECONNECTING;
            }else if(a2dp_source_establish_stream(peer,&cid)){
                stats->a2dp_last_status=0xe2;ended=1;
            }
            break;
        case HCI_EVENT_CONNECTION_COMPLETE:
            if(size>=13u){
                bd_addr_t addr;
                hci_event_connection_complete_get_bd_addr(p,addr);
                if(!memcmp(addr,peer,6)){
                    stats->bond_acl_events++;
                    stats->bond_acl_status=hci_event_connection_complete_get_status(p);
                }
            }
            break;
        case HCI_EVENT_LINK_KEY_REQUEST:
            if(size>=8u){
                bd_addr_t addr;
                hci_event_link_key_request_get_bd_addr(p,addr);
                if(!memcmp(addr,peer,6))stats->bond_link_key_requests++;
            }
            break;
        case HCI_EVENT_LINK_KEY_NOTIFICATION:
            if(size>=25u){
                bd_addr_t addr;
                hci_event_link_key_request_get_bd_addr(p,addr);
                if(!memcmp(addr,peer,6)){
                    stats->bond_key_notifications++;
                    stats->bond_last_new_key_type=p[24];
                }
            }
            break;
        case HCI_EVENT_COMMAND_COMPLETE:
            if(size>=6u){
                uint16_t opcode=hci_event_command_complete_get_command_opcode(p);
                if(opcode==0x040bu){
                    if(p[5]==0)stats->bond_key_reply_ok++;
                    else stats->bond_key_reply_fail++;
                }else if(opcode==0x040cu){
                    stats->bond_key_negative++;
                }
            }
            break;
        case HCI_EVENT_AUTHENTICATION_COMPLETE_EVENT:
            if(size>=5u){
                stats->bond_auth_events++;
                stats->bond_auth_status=p[2];
            }
            break;
        case HCI_EVENT_ENCRYPTION_CHANGE:
            if(size>=6u){
                stats->bond_encrypt_events++;
                stats->bond_encrypt_status=hci_event_encryption_change_get_status(p);
                stats->bond_encrypt_enabled=hci_event_encryption_change_get_encryption_enabled(p);
            }
            break;
        case HCI_EVENT_ENCRYPTION_CHANGE_V2:
            if(size>=7u){
                stats->bond_encrypt_events++;
                stats->bond_encrypt_status=p[2];
                stats->bond_encrypt_enabled=p[5];
            }
            break;
        case HCI_EVENT_DISCONNECTION_COMPLETE:
            if(size>=6u){
                stats->bond_disconnect_events++;
                stats->bond_disconnect_reason=hci_event_disconnection_complete_get_reason(p);
            }
            break;
        case HCI_EVENT_USER_CONFIRMATION_REQUEST: {
            bd_addr_t address;
            hci_event_user_confirmation_request_get_bd_addr(p,address);
            if(!memcmp(address,peer,6))gap_ssp_confirmation_response(address);
            else gap_ssp_confirmation_negative(address);
            break;
        }
        case HCI_EVENT_PIN_CODE_REQUEST: {
            bd_addr_t address;hci_event_pin_code_request_get_bd_addr(p,address);
            gap_pin_code_negative(address);
            break;
        }
        default:break;
    }
}
/* Called only after the POC3 firmware has been downloaded and the POC4
 * vendor baud switch has been confirmed at 921600. Never shares UART parsers. */
unsigned bt_poc6_run(volatile struct bt_hci_diag_shared *p,const uint8_t peer_display[6],unsigned paula_mode,
                 const uint8_t bond[16],unsigned bond_type,unsigned bond_valid,
                 volatile struct bt_hci_control_shared *control){
    stats=p;recover_requested=0;started=ended=send_pending=finish_requested=0;cid=0;seid=0;encoder=0;
    p9_state=P9_IDLE;p9_close_sent=0;p9_due=p9_attempt_at=p9_close_at=0;
    p9_backoff=P9_BACKOFF_FIRST_MS;
    live_paula=paula_mode;
    poc8_ctrl=control;
    /* 0xff represents not observed, not HCI success. */
    p->bond_acl_status=0xffu;
    p->bond_auth_status=0xffu;
    p->bond_encrypt_status=0xffu;
    p->bond_disconnect_reason=0xffu;
    /* An in-flight RECOVER command survives the new epoch until HCI reaches
     * WORKING. Do NOT consume it again while BTstack is powering on. */
    poc8_last_command=control ?
        (p->recover_stage==3u ? control->request_seq : control->completed_seq) : 0;
    send_requested_at=0;
    for(unsigned i=0;i<6;i++)peer[i]=peer_display[i];
    /* The memory-only DB is a singleton; a prior epoch may have left a
     * pointer into the old pool. Clear its list before pool reinitialization.
     * The persistent bt_bond is installed again immediately below. */
    extern btstack_linked_list_t db_mem_link_keys;
    db_mem_link_keys=NULL;
    btstack_memory_init();
    btstack_run_loop_init(btstack_run_loop_embedded_get_instance());
    hci_init(bt_poc6_transport(),NULL);
    hci_set_link_key_db(btstack_link_key_db_memory_instance());
    if(bond_valid || recover_ram_key_valid){
        /* Install BEFORE power on and any outgoing ACL/authentication. */
        link_key_t stored;
        unsigned effective_type=bond_valid?bond_type:recover_ram_type;
        for(unsigned i=0;i<16;i++) stored[i]=bond_valid?bond[i]:recover_ram_key[i];
        gap_store_link_key_for_bd_addr(peer,stored,(link_key_type_t)effective_type);
        {
            link_key_t readback;
            link_key_type_t stored_type=INVALID_LINK_KEY;
            bool have=gap_get_link_key_for_bd_addr(peer,readback,&stored_type);
            p->bond_db_readback=(have && stored_type==(link_key_type_t)effective_type &&
                                 memcmp(readback,stored,16)==0) ? 1u : 2u;
            memset(readback,0,sizeof(readback));
        }
        memset(stored,0,sizeof(stored));
        p->bond_loaded=1;
    }
    l2cap_init();
    a2dp_source_init();
    a2dp_source_register_packet_handler(a2dp_handler);
    avdtp_stream_endpoint_t *endpoint=a2dp_source_create_stream_endpoint(
        AVDTP_AUDIO,AVDTP_CODEC_SBC,sbc_cap,sizeof(sbc_cap),sbc_config,sizeof(sbc_config));
    if(!endpoint){p->stop_reason=BTDIAG_STOP_A2DP_INIT_FAILED;goto init_failed;}
    seid=avdtp_local_seid(endpoint);
    avdtp_set_preferred_sampling_frequency(endpoint,48000);
    sdp_init();
    memset(sdp_record,0,sizeof(sdp_record));
    a2dp_source_create_sdp_record(sdp_record,sdp_create_service_record_handle(),
                 AVDTP_SOURCE_FEATURE_MASK_PLAYER,NULL,NULL);
    sdp_register_service(sdp_record);
    gap_set_local_name("Emu68 Paula-BT POC6");
    gap_discoverable_control(0);
    gap_set_bondable_mode(1);
    gap_ssp_set_io_capability(SSP_IO_CAPABILITY_NO_INPUT_NO_OUTPUT);
    hci_callback.callback=hci_handler;
    hci_add_event_handler(&hci_callback);
    global_started_at=btstack_run_loop_get_time_ms();
    p->a2dp_stack_started=1;
    p->stop_reason=BTDIAG_STOP_A2DP_TIMEOUT;
    if(hci_power_control(HCI_POWER_ON)){
        p->stop_reason=BTDIAG_STOP_A2DP_INIT_FAILED;goto init_failed;
    }
    for(;;){
        btstack_run_loop_embedded_execute_once();
        poc8_service_key_request();
        if(recover_requested) break;
        uint32_t now=btstack_run_loop_get_time_ms();
        /* A controller stuck during the second HCI power-on must not leave
         * --recover pending forever. This guard is ONLY for manual recovery,
         * never the validated ordinary cold-boot / A2DP reconnect path. */
        if(p->recover_stage==3u && !p->a2dp_controller_working &&
           (uint32_t)(now-global_started_at)>25000u){
            p->stop_reason=BTDIAG_STOP_A2DP_INIT_FAILED;
            goto init_failed;
        }
        p9_work(now);
#if defined(EMU68_BT_PAULA_POC7)
        if(live_paula){
            emu68_paula_bt_snapshot(p);
            p->a2dp_elapsed_ms=now-global_started_at;
            /* Live stream: no arbitrary 8s disconnect; update transport
             * counters periodically, visible to BTDiag while running. */
            if((now&255u)==0u){
                p->a2dp_transport_errors=bt_poc6_transport_errors();
                bt_poc6_transport_diag_snapshot(p);
                bt_poc6_transport_snapshot(&p->a2dp_acl_tx_packets,&p->a2dp_acl_tx_bytes,
                    &p->a2dp_acl_completed,&p->a2dp_acl_completion_events,&p->a2dp_acl_rx_packets);
            }
        }
#endif
        if(!live_paula && started&&!finish_requested && now-tone_started_at>=8000u){
            finish_requested=1;
            btstack_run_loop_remove_timer(&send_timer);
            a2dp_source_disconnect(cid);
        }
        if(!live_paula && finish_requested && now-tone_started_at>=10000u)break;
        if((ended && !live_paula) || (!live_paula && now-global_started_at>=45000u))break;
        /* POC7 stays resident on CPU3 while the A2DP session is alive. */
    }
#if defined(EMU68_BT_PAULA_POC7)
    if(live_paula)emu68_paula_bt_snapshot(p);
#endif
    p->a2dp_elapsed_ms=btstack_run_loop_get_time_ms()-global_started_at;
    p->a2dp_transport_errors=bt_poc6_transport_errors();
    bt_poc6_transport_diag_snapshot(p);
    bt_poc6_transport_snapshot(&p->a2dp_acl_tx_packets,&p->a2dp_acl_tx_bytes,
        &p->a2dp_acl_completed,&p->a2dp_acl_completion_events,
        &p->a2dp_acl_rx_packets);
    if(recover_requested){
        /* Retain a just-paired key even if bt_bond has not been added yet.
         * It remains in private CPU3 memory, never in the diag aperture. */
        {
            link_key_type_t key_type=INVALID_LINK_KEY;
            recover_ram_key_valid=gap_get_link_key_for_bd_addr(
                    peer,recover_ram_key,&key_type)?1u:0u;
            if(recover_ram_key_valid)recover_ram_type=(unsigned)key_type;
        }
        /* The BCM may now be at power-on UART baud and no longer know its
         * ACL handle. Never send HCI_POWER_OFF / AVDTP Disconnect across
         * this desynchronised transport; do local CPU3-only teardown. */
        p9_clear_stream();
        bt_poc6_transport()->close(); /* remove poll data source first */
        a2dp_source_deinit();
        sdp_deinit();
        sdp_client_deinit();
        l2cap_deinit();
        hci_deinit();
        btstack_memory_deinit();
        btstack_run_loop_deinit();
        p->a2dp_stack_started=0;
        p->a2dp_controller_working=0;
        p->a2dp_reconnect_state=P9_IDLE;
        return 1u;
    }
    if(p->a2dp_packets && p->a2dp_stream_started && finish_requested)
        p->stop_reason=BTDIAG_STOP_A2DP_TONE_COMPLETE;
    else if(ended)p->stop_reason=BTDIAG_STOP_A2DP_STREAM_FAILED;
    /* Only explicit --recover escapes POC9 Paula mode; all ordinary ACL/
     * A2DP failures remain under POC9's tested autonomous retry policy. */
    return 0u;
init_failed:
    /* Allow another explicit recovery if HCI power-on or endpoint allocation
     * fails. No power-cycle or request to WLAN is issued here. */
    bt_poc6_transport()->close();
    a2dp_source_deinit();
    sdp_deinit();
    sdp_client_deinit();
    l2cap_deinit();
    hci_deinit();
    btstack_memory_deinit();
    btstack_run_loop_deinit();
    return 0u;
}
