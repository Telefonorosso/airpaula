/* BTstack error-log formatting uses vsnprintf. Emu68 already provides
 * my_vsnprintf() via its tiny vkprintf_pc formatter; avoid libc/newlib.
 * SPDX-License-Identifier: MPL-2.0
 */
#include <stdarg.h>
#include <stddef.h>
extern int my_vsnprintf(char *, size_t, const char *, va_list);
int vsnprintf(char *dst, size_t len, const char *fmt, va_list ap){
    return my_vsnprintf(dst,len,fmt,ap);
}
