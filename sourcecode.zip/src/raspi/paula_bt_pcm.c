/* Paula-BT POC7: producer from hardware-validated Paula USB CACHE-FIX2.
 * The renderer and register/cache semantics are intentionally unchanged.
 * SPDX-License-Identifier: MPL-2.0 */
#include <stdint.h>
#include "support.h"
#include "paula/paula_live.h"
#include "paula/paula_mirror.h"
#include "paula_probe.h"
#include "paula/paula_replay.h"
#include "paula_bt_pcm.h"

#if defined(PISTORM_CLASSIC) && defined(EMU68_BT_PAULA_POC7)
/* Parsed on CPU0 before CPU1 is started; no FDT or SD access on CPU1. */
extern unsigned bt_hci_paula_clock_ntsc(void);
#define PAULA_BT_RATE 48000u
/* The original USB producer used these local ARM generic-timer helpers. */
static inline uint64_t read_cntvct(void){uint64_t v;__asm__ volatile("mrs %0, cntvct_el0":"=r"(v));return v;}
static inline uint64_t read_cntfrq(void){uint64_t v;__asm__ volatile("mrs %0, cntfrq_el0":"=r"(v));return v;}
static volatile uint32_t paula_bt_enabled;
static volatile uint32_t paula_bt_packets;
static volatile uint32_t paula_bt_underruns;
static volatile uint32_t paula_bt_overruns;
static volatile uint32_t paula_bt_nonzero;
static volatile uint32_t paula_bt_pcm_produced;
static volatile uint32_t paula_bt_pcm_pulled;
static volatile uint32_t paula_bt_peak;
#define PAULA_BT_RING_FRAMES 2048u
#define PAULA_BT_RING_MASK (PAULA_BT_RING_FRAMES-1u)
#define PAULA_BT_TARGET 384u
struct paula_bt_frame { int16_t left, right; };
static struct paula_bt_frame paula_bt_ring[PAULA_BT_RING_FRAMES];
static volatile uint32_t paula_bt_wr;
static volatile uint32_t paula_bt_rd;
static int16_t last_l, last_r;

static int16_t float_to_s16(float sample) {
    if (sample > 1.0f) sample=1.0f;
    if (sample < -1.0f) sample=-1.0f;
    return sample >= 0.0f ? (int16_t)(sample*32767.0f) : (int16_t)(sample*32768.0f);
}
void emu68_paula_bt_init(void){
    /* Called on CPU0 before secondary cores are released. No USB/MMIO. */
    paula_bt_wr=paula_bt_rd=0;
    paula_bt_packets=paula_bt_underruns=paula_bt_overruns=0;
    paula_bt_pcm_produced=paula_bt_pcm_pulled=paula_bt_peak=paula_bt_nonzero=0;
    last_l=last_r=0;
    __atomic_store_n(&paula_bt_enabled,1u,__ATOMIC_RELEASE);
    __asm__ volatile("sev" ::: "memory");
}
static uint32_t paula_bt_ring_fill(void){
    uint32_t wr=__atomic_load_n(&paula_bt_wr,__ATOMIC_ACQUIRE);
    uint32_t rd=__atomic_load_n(&paula_bt_rd,__ATOMIC_ACQUIRE);
    uint32_t n=wr-rd;
    return n>PAULA_BT_RING_FRAMES?PAULA_BT_RING_FRAMES:n;
}
static void paula_bt_ring_push(int16_t l,int16_t r){
    uint32_t wr=__atomic_load_n(&paula_bt_wr,__ATOMIC_RELAXED);
    paula_bt_ring[wr & PAULA_BT_RING_MASK]=(struct paula_bt_frame){l,r};
    __atomic_store_n(&paula_bt_wr,wr+1u,__ATOMIC_RELEASE);
    __atomic_add_fetch(&paula_bt_pcm_produced,1u,__ATOMIC_RELAXED);
    if(l || r)__atomic_add_fetch(&paula_bt_nonzero,1u,__ATOMIC_RELAXED);
}
/* CPU3: read N interleaved 16-bit stereo frames, always deliver N (silence on
 * underrun). On late startup drop stale audio to a recent 8ms preroll.
 * Once locked, at most one sample adjustment per 128-frame group to arrest
 * slow drift between ARM renderer clock and the receiver's clock. */
void emu68_paula_bt_read_pcm(int16_t *out,unsigned frames){
    uint32_t wr=__atomic_load_n(&paula_bt_wr,__ATOMIC_ACQUIRE);
    uint32_t rd=__atomic_load_n(&paula_bt_rd,__ATOMIC_RELAXED);
    uint32_t fill=wr-rd;
    if(fill>PAULA_BT_RING_FRAMES){
        rd=wr-PAULA_BT_TARGET;fill=PAULA_BT_TARGET;
        __atomic_add_fetch(&paula_bt_overruns,1u,__ATOMIC_RELAXED);
    }
    /* When aligned, a single-frame duplication/drop corrects small drift. */
    unsigned consume=frames;
    if(fill>PAULA_BT_TARGET+160u && fill>frames+1u) consume=frames+1u;
    else if(fill<PAULA_BT_TARGET-160u && fill>=frames) consume=frames-1u;
    unsigned usable=fill<consume?fill:consume;
    if(usable<consume) __atomic_add_fetch(&paula_bt_underruns,1u,__ATOMIC_RELAXED);
    for(unsigned i=0;i<frames;i++){
        unsigned index=i;
        if(consume==frames-1u && i==frames-1u)index=frames-2u;
        struct paula_bt_frame f={0,0};
        if(index<usable)f=paula_bt_ring[(rd+index)&PAULA_BT_RING_MASK];
        out[2*i]=f.left;out[2*i+1]=f.right;
        uint32_t a=(uint32_t)(f.left<0?-(int32_t)f.left:f.left);
        if(a>paula_bt_peak)paula_bt_peak=a;
        a=(uint32_t)(f.right<0?-(int32_t)f.right:f.right);
        if(a>paula_bt_peak)paula_bt_peak=a;
    }
    if(usable){
        __atomic_store_n(&paula_bt_rd,rd+usable,__ATOMIC_RELEASE);
        __atomic_add_fetch(&paula_bt_pcm_pulled,usable,__ATOMIC_RELAXED);
    }
    __atomic_add_fetch(&paula_bt_packets,1u,__ATOMIC_RELAXED);
}
void emu68_paula_bt_snapshot(volatile struct bt_hci_diag_shared *d){
    d->paula_pcm_produced=__atomic_load_n(&paula_bt_pcm_produced,__ATOMIC_RELAXED);
    d->paula_pcm_consumed=__atomic_load_n(&paula_bt_pcm_pulled,__ATOMIC_RELAXED);
    d->paula_ring_fill=paula_bt_ring_fill();
    d->paula_underruns=__atomic_load_n(&paula_bt_underruns,__ATOMIC_RELAXED);
    d->paula_overruns=__atomic_load_n(&paula_bt_overruns,__ATOMIC_RELAXED);
    d->paula_pcm_peak=__atomic_load_n(&paula_bt_peak,__ATOMIC_RELAXED);
    d->paula_nonzero_frames=__atomic_load_n(&paula_bt_nonzero,__ATOMIC_RELAXED);
    d->paula_capture_drops=paula_mirror_dropped();
    d->paula_cache_misses=paula_mirror_misses();
}
typedef struct {
    uint32_t loc[4];
    uint16_t len[4];
    uint16_t dma;
} poc_live_state;

static void poc_prefetch_channel(const poc_live_state *state, unsigned ch)
{
    const uint32_t bytes = (state->len[ch] ? state->len[ch] : 65536u) * 2u;
    paula_mirror_prefetch(state->loc[ch], bytes < 1024u ? bytes : 1024u);
}

static void poc_apply_live_event(poc_live_state *state,
                                 const paula_mirror_event *event)
{
    if (event->width != 1u && event->width != 2u) {
        paula_probe_add(PP_IGNORED,1);
        return;
    }
    if (event->width == 2u && (event->address & 1u)) {
        paula_probe_add(PP_IGNORED,1);
        return;
    }

    const uint32_t r = event->address & 0xffeu;
    const uint16_t value = event->width == 1u
        ? (uint16_t)((event->value & 255u) * 0x0101u)
        : event->value;

    if (r >= 0xa0u && r <= 0xdau) {
        const unsigned ch = (r - 0xa0u) >> 4;
        const unsigned reg = (r - 0xa0u) & 0x0fu;
        if (ch < 4u) {
            if (reg == 0u)
                state->loc[ch] = (state->loc[ch] & 0xffffu) |
                                 ((uint32_t)value << 16);
            else if (reg == 2u) {
                state->loc[ch] = (state->loc[ch] & 0xffff0000u) | value;
                if (state->len[ch])
                    poc_prefetch_channel(state, ch);
            } else if (reg == 4u) {
                state->len[ch] = value;
                poc_prefetch_channel(state, ch);
            }
        }
    } else if (r == 0x096u) {
        const uint16_t before = state->dma;
        if (value & 0x8000u)
            state->dma |= value & 0x7fffu;
        else
            state->dma &= (uint16_t)~(value & 0x7fffu);
        if (state->dma & 0x0200u) {
            for (unsigned ch = 0; ch < 4u; ++ch) {
                const uint16_t mask = (uint16_t)(0x0200u | (1u << ch));
                if ((state->dma & mask) == mask && (before & mask) != mask)
                    poc_prefetch_channel(state, ch);
            }
        }
    }

    paula_live_write(0xdff000u | r, value);
    if (r == 0x096u || (r >= 0x0a0u && r <= 0x0dau &&
        ((r - 0x0a0u) & 15u) <= 4u))
        paula_live_prefetch();
}

static int poc_restore_live_state(poc_live_state *state,
                                  paula_mirror_snapshot *snapshot)
{
    if (!paula_mirror_snapshot_take(snapshot))
        return 0;

    paula_probe_flag(PP_FLAG_CAPTURE_FAILED,1);
    paula_live_reset();
    for (unsigned ch = 0; ch < 4u; ++ch) {
        state->loc[ch] = 0;
        state->len[ch] = 0;
    }
    state->dma = 0;

    for (unsigned ch = 0; ch < 4u; ++ch) {
        for (unsigned reg = 0; reg < 5u; ++reg) {
            if (!(snapshot->seen[ch] & (1u << reg)))
                continue;
            paula_mirror_event event;
            event.address = 0xdff0a0u + ch * 16u + reg * 2u;
            event.value = snapshot->reg[ch][reg];
            event.width = 2u;
            event.reserved = 0;
            event.ticks = snapshot->ticks;
            poc_apply_live_event(state, &event);
        }
    }
    if (snapshot->seen_global & 2u)
        paula_live_write(0xdff09au, (uint16_t)(0x8000u | snapshot->intena));
    if (snapshot->seen_global & 4u)
        paula_live_write(0xdff09cu, (uint16_t)(0x8000u | snapshot->intreq));
    if (snapshot->seen_global & 8u)
        paula_live_write(0xdff09eu, (uint16_t)(0x8000u | snapshot->adkcon));
    if (snapshot->seen_global & 1u) {
        paula_mirror_event event;
        event.address = 0xdff096u;
        event.value = (uint16_t)(0x8000u | snapshot->dma);
        event.width = 2u;
        event.reserved = 0;
        event.ticks = snapshot->ticks;
        poc_apply_live_event(state, &event);
    }

    paula_probe_add(PP_RESYNCS,1u);
    paula_probe_add(PP_RESYNC_SKIPPED,snapshot->skipped);
    paula_probe_flag(PP_FLAG_CAPTURE_FAILED,0);
    return 1;
}

void emu68_paula_bt_cpu1_worker(void)
{
    while (!__atomic_load_n(&paula_bt_enabled, __ATOMIC_ACQUIRE))
        asm volatile("wfe");

    paula_probe_init();
    paula_probe_set(PP_SAMPLE_RATE, PAULA_BT_RATE);
    paula_probe_set(PP_COUNTER_FREQ, (uint32_t)read_cntfrq());
    const unsigned ntsc = bt_hci_paula_clock_ntsc();
    paula_live_init_clock(ntsc);
    paula_mirror_enable();
    paula_probe_flag(PP_FLAG_RENDERING, 1);
    kprintf("[PAULA-BT] CPU1 Paula CACHE-FIX2 producer active, 48 kHz stereo, %s clock\n",
            ntsc ? "NTSC" : "PAL");

    poc_live_state state;
    for (unsigned ch = 0; ch < 4u; ++ch) {
        state.loc[ch] = 0;
        state.len[ch] = 0;
    }
    state.dma = 0;

    paula_mirror_event event;
    paula_mirror_snapshot snapshot;
    uint32_t frames_written = 0;
    uint32_t last_drop = paula_mirror_dropped();
    unsigned recovery_pending = 0;
    uint64_t last_report = read_cntvct();
    const uint64_t frequency = read_cntfrq();
    const uint64_t latency = frequency / 20u;
    const uint64_t max_lag = frequency / 4u;
    paula_replay_clock clock;
    paula_replay_start(&clock, last_report, (uint32_t)frequency, latency);

    for (;;) {
        paula_live_mixer_apply();
        uint64_t now = read_cntvct();
        const uint32_t drops = paula_mirror_dropped();

        if (drops != last_drop ||
            paula_mirror_pending() >= PAULA_MIRROR_EVENT_CAPACITY * 3u / 4u ||
            paula_replay_late(&clock, now, latency, max_lag))
            recovery_pending = 1;

        if (recovery_pending) {
            paula_probe_flag(PP_FLAG_CAPTURE_FAILED,1);
            if (poc_restore_live_state(&state, &snapshot)) {
                last_drop = snapshot.dropped;
                paula_replay_start(&clock, read_cntvct(),
                                   (uint32_t)frequency, latency);
                recovery_pending = 0;
            } else {
                paula_probe_add(PP_SNAPSHOT_RETRIES,1u);
            }
        }
        const unsigned recovering = recovery_pending;

        while (!recovering &&
               !paula_replay_due(read_cntvct(), clock.tick + latency))
            asm volatile("yield");

        unsigned processed = 0;
        while (!recovering && processed < 128u && paula_mirror_peek(&event)) {
            if (!paula_replay_due(clock.tick, event.ticks))
                break;
            poc_apply_live_event(&state, &event);
            paula_mirror_pop();
            ++processed;
        }

        unsigned backlog = 0;
        if (!recovering && paula_mirror_peek(&event) &&
            paula_replay_due(clock.tick, event.ticks))
            backlog = 1;

        float left = 0.0f, right = 0.0f;
        if (!recovering && !backlog)
            paula_live_render(&left, &right, 1u);
        else
            paula_probe_add(PP_REPLAY_SILENT_FRAMES,1u);

        const int16_t sl = float_to_s16(left);
        const int16_t sr = float_to_s16(right);
        paula_bt_ring_push(sl, sr);

        if (sl || sr)
            paula_probe_add(PP_NONZERO_FRAMES,1u);
        const uint32_t abs_l = (uint32_t)(sl < 0 ? -(int32_t)sl : sl);
        const uint32_t abs_r = (uint32_t)(sr < 0 ? -(int32_t)sr : sr);
        if (abs_l > paula_probe_get(PP_PEAK_LEFT))
            paula_probe_set(PP_PEAK_LEFT, abs_l);
        if (abs_r > paula_probe_get(PP_PEAK_RIGHT))
            paula_probe_set(PP_PEAK_RIGHT, abs_r);

        ++frames_written;
        paula_probe_set(PP_PCM_FRAMES, frames_written);
        paula_replay_advance(&clock);

        now = read_cntvct();
        if (now - last_report >= frequency) {
            const uint64_t target = clock.tick + latency;
            const uint64_t lag = paula_replay_due(now, target) ? now - target : 0;
            paula_probe_set(PP_REPLAY_LAG_US,
                (uint32_t)((lag * 1000000u) / frequency));
            kprintf("[PAULA-BT] PCM=%u ring=%u pkt=%u under=%u over=%u miss=%u drop=%u\n",
                    frames_written, paula_bt_ring_fill(),
                    __atomic_load_n(&paula_bt_packets, __ATOMIC_RELAXED),
                    __atomic_load_n(&paula_bt_underruns, __ATOMIC_RELAXED),
                    __atomic_load_n(&paula_bt_overruns, __ATOMIC_RELAXED),
                    paula_mirror_misses(), paula_mirror_dropped());
            last_report = now;
        }
    }
}


#endif
