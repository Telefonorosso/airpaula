/*
 * Emu68 PiStorm Classic / Raspberry Pi 3A+ - opt-in Bluetooth HCI UART.
 * POC8 extends the hardware-validated POC7 A2DP path with first-run scan,
 * native DT address, and explicit BTstack bond import/export.
 * Never touches WLAN SDIO, firmware expander GPIOs or BT/WLAN power.
 *
 * Copyright (c) 2026 Emu68 Paula-BT proof-of-concept contributors.
 * SPDX-License-Identifier: MPL-2.0
 */

#include <stdint.h>
#define ARM_PERIIOBASE 0xf2000000u
#include "support.h"
#include "support_rpi.h"
#include "devicetree.h"
#include "mmu.h"
#include "tlsf.h"
#include "bt_hci_shared.h"

#define IO_BASE              0xf2000000u /* Pi 3A+, mapped by Emu68 */
#define GPIO_BASE_RPI        (IO_BASE + 0x200000u)
#define GPIO_GPFSEL3         (GPIO_BASE_RPI + 0x0cu)
#define GPIO_GPFSEL4         (GPIO_BASE_RPI + 0x10u)
#define CM_GP2CTL            (IO_BASE + 0x101080u)
#define CM_GP2DIV            (IO_BASE + 0x101084u)
#define GPIO_FSEL_ALT3       7u
#define GPIO_FSEL_ALT0       4u

#define PL011_IMSC_ALL       0u
#define PL011_ICR_ALL        0x7ffu
#define HCI_EVENT_PACKET     0x04u
#define HCI_COMMAND_PACKET   0x01u
#define HCI_EVENT_COMPLETE   0x0eu
#define HCI_RESET_OPCODE     0x0c03u
#define HCI_VERSION_OPCODE   0x1001u
#define HCI_BDADDR_OPCODE    0x1009u
#define HCI_DOWNLOAD_OPCODE  0xfc2eu
#define HCI_BCM_SET_BAUD     0xfc18u
#define HCI_BCM_SET_BDADDR   0xfc01u
#define HCI_INQUIRY_OPCODE   0x0401u
#define HCI_INQUIRY_MODE     0x0c45u
#define HCI_SET_EVENT_MASK   0x0c01u

static unsigned probe_mode; /* 0..5 legacy, 6=A2DP tone, 7=Paula A2DP */
/* POC11-A: cmdline.txt standalone token "pause" postpones only CPU3 BT init. */
static unsigned bt_boot_pause_60s;
static uint8_t configured_bd_addr[6]; /* display order: override or DT */
static unsigned configured_bd_addr_source; /* 1 explicit, 2 Device Tree */
static unsigned configured_bd_addr_valid;
static unsigned configured_bd_addr_bad;
#ifdef EMU68_BT_HCI_POC5
static uint8_t configured_peer_addr[6]; /* display order */
static unsigned configured_peer_valid;
static unsigned configured_peer_bad;
static uint8_t pair_link_key[16]; /* ARM-only RAM; never write to BTDiag */
static unsigned pair_key_valid;
#ifdef EMU68_BT_HCI_POC6
static uint8_t configured_bond_key[16];
static unsigned configured_bond_type;
#endif
static unsigned configured_bond_valid, configured_bond_bad;
#endif

#ifdef EMU68_BT_HCI_POC3
extern const uint8_t bt_bcm_patchram[];
extern const unsigned bt_bcm_patchram_len;
extern const unsigned bt_bcm_patchram_commands;
#endif
#ifdef EMU68_BT_HCI_POC6
extern unsigned bt_poc6_run(volatile struct bt_hci_diag_shared*,const uint8_t peer_display[6], unsigned live_paula,
                        const uint8_t bond[16], unsigned bond_type, unsigned bond_valid,
                        volatile struct bt_hci_control_shared *control);
#endif
#if defined(EMU68_BT_PAULA_POC7)
/* Boot configuration is parsed on CPU0, before the Paula renderer on CPU1. */
static unsigned paula_clock_ntsc; /* default 0 = PAL, even without a token */
int bt_hci_paula_requested(void) { return probe_mode == 7u && configured_peer_valid; }
unsigned bt_hci_paula_clock_ntsc(void) { return paula_clock_ntsc; }
#endif
static uint32_t uart_clock_hz; /* filled on CPU0, mailbox isn't used from CPU3 */
static volatile struct bt_hci_diag_shared *diag_page;
static volatile struct bt_hci_control_shared *control_page;
/* POC11-B: CPU3-only rebootstrap request, never issued by WiFiPi. */
static unsigned bt_manual_recover_pending;

/* Allocated from kernel-only memory: never returned to the Amiga RAM pool. */
void bt_hci_shared_init(void)
{
    void *page = tlsf_malloc_aligned(tlsf, 4096u, 4096u);
    if (!page) {
        kprintf("[BT-HCI] ERROR: cannot allocate diagnostic page\n");
        return;
    }
    memset(page, 0, 4096u);
    diag_page = (volatile struct bt_hci_diag_shared *)page;
    diag_page->magic = BTDIAG_MAGIC;
    diag_page->version = BTDIAG_VERSION;
    diag_page->size = sizeof(*diag_page);
    diag_page->mode = probe_mode;
    diag_page->state = BTDIAG_STATE_WAIT;
    diag_page->uart_clock_hz = uart_clock_hz;
    diag_page->reset_rc = -99;
    diag_page->version_rc = -99;
    diag_page->reset_status = 0xffu;
    diag_page->version_status = 0xffu;
    diag_page->scan_mode = 0xffffffffu;
    diag_page->bd_addr_source = configured_bd_addr_source;
#ifdef EMU68_BT_HCI_POC5
    diag_page->bond_configured = configured_bond_valid;
#endif
#ifdef EMU68_BT_HCI_POC5
    if (configured_peer_valid) {
        diag_page->pair_requested = 1;
        for (unsigned i = 0; i < 6; ++i)
            diag_page->pair_peer[i] = configured_peer_addr[i];
    }
#endif
    diag_page->address_config_state = configured_bd_addr_bad ? 3u :
        (configured_bd_addr_valid ? 1u : 0u);
    /* Keep POC7 diagnostic aperture READ-ONLY. Only a separate command page
     * can be written by AmigaOS. Noncacheable prevents stale cross-core data.
     */
    void *cmd = tlsf_malloc_aligned(tlsf, 4096u, 4096u);
    if (cmd) {
        /* Access through the non-cacheable virtual mapping on ALL ARM
         * cores, not through the cached TLSF alias: no dirty-cache aliasing.
         */
        mmu_map(mmu_virt2phys((uintptr_t)cmd), BTCTRL_ADDRESS, 4096u,
                MMU_ACCESS | MMU_ISHARE | MMU_ALLOW_EL0 | MMU_ATTR_UNCACHED, 0);
        control_page = (volatile struct bt_hci_control_shared *)(uintptr_t)BTCTRL_ADDRESS;
        memset((void *)control_page, 0, 4096u);
        control_page->magic = BTCTRL_MAGIC;
        control_page->version = BTCTRL_VERSION;
        control_page->size = sizeof(*control_page);
    }
    /* Fixed experimental M68k aperture, mapped only in this Pi 3A+ POC. */
    mmu_map(mmu_virt2phys((uintptr_t)page), BTDIAG_ADDRESS, 4096u,
            MMU_ACCESS | MMU_ISHARE | MMU_ALLOW_EL0 |
            MMU_READ_ONLY | MMU_ATTR_CACHED, 0);
    /* Advertise the aperture in Emu68's FDT for future tools. */
    uint32_t address = BTDIAG_ADDRESS;
    of_node_t *emu = dt_find_node("/emu68");
    if (emu) {
        dt_add_property(emu, "paula-bt-diag-addr", &address, sizeof(address));
        if (control_page) {
            uint32_t control_address = BTCTRL_ADDRESS;
            dt_add_property(emu, "paula-bt-control-addr", &control_address, sizeof(control_address));
        }
    }
    dsb();
}

static void diag_done(void)
{
    if (diag_page) {
        dsb();
        diag_page->state = BTDIAG_STATE_DONE;
        dsb();
    }
}

static void diag_restored(void)
{
    if (diag_page) {
        diag_page->uart_restored = 1;
        dsb();
    }
}


static uint64_t counter_now(void)
{
    uint64_t cnt;
    __asm__ volatile("mrs %0, CNTVCT_EL0" : "=r"(cnt));
    return cnt;
}

static uint64_t counter_deadline_ms(unsigned ms)
{
    uint64_t freq;
    __asm__ volatile("mrs %0, CNTFRQ_EL0" : "=r"(freq));
    return counter_now() + ((freq * ms) / 1000u);
}

static int before_deadline(uint64_t deadline)
{
    return (int64_t)(counter_now() - deadline) < 0;
}

/* Inspect ONLY /chosen/bootargs (cmdline.txt), not /emu68/args (config.txt).
 * Exact, whitespace-delimited token; deliberately avoid find_token's prefix
 * behavior. No writes to GPIO, shared WLAN power, SDIO, or BT control state.
 */
static int bt_cmdline_has_pause(const char *s)
{
    if (!s) return 0;
    while (*s) {
        while (*s == ' ' || *s == '\t' || *s == '\r' || *s == '\n') ++s;
        const char *start = s;
        while (*s && *s != ' ' && *s != '\t' && *s != '\r' && *s != '\n') ++s;
        if ((s - start) == 5 &&
            start[0] == 'p' && start[1] == 'a' && start[2] == 'u' &&
            start[3] == 's' && start[4] == 'e') return 1;
    }
    return 0;
}

static unsigned gpio_function(uint32_t fsel, unsigned gpio)
{
    return (fsel >> ((gpio % 10u) * 3u)) & 7u;
}

/* Emu68 1.1 supports both legacy /chosen/bootargs and /emu68/args.
 * Prefer the active probe if both sources happen to specify a mode.
 */
/* Reject invalid address tokens. POC8 additionally reads the native
 * address from the Device Tree when no explicit bt_bdaddr= was supplied.
 * Broadcom's 43:45:C0:00:1F:AC is shared and is NEVER safe for pairing.
 */
static int bt_hex(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static int parse_bd_addr(const char *s, uint8_t out[6])
{
    for (unsigned i = 0; i < 6; ++i) {
        if (!s[0]) return 0;
        int a = bt_hex(s[0]);
        if (a < 0 || !s[1]) return 0;
        int b = bt_hex(s[1]);
        if (b < 0) return 0;
        out[i] = (uint8_t)((a << 4) | b);
        s += 2;
        if (i != 5) {
            if (*s != ':') return 0;
            ++s;
        }
    }
    if (*s && *s != ' ' && *s != '\t') return 0;
    if (out[0] == 0 && out[1] == 0 && out[2] == 0 &&
        out[3] == 0 && out[4] == 0 && out[5] == 0) return 0;
    if (out[0] == 0xff && out[1] == 0xff && out[2] == 0xff &&
        out[3] == 0xff && out[4] == 0xff && out[5] == 0xff) return 0;
    if (out[0] == 0x43 && out[1] == 0x45 && out[2] == 0xc0 &&
        out[3] == 0x00 && out[4] == 0x1f && out[5] == 0xac) return 0;
    return 1;
}

#ifdef EMU68_BT_PAULA_POC7
static int valid_native_bd_addr(const uint8_t addr[6])
{
    unsigned nz = 0, nf = 0;
    for (unsigned i = 0; i < 6; ++i) {
        nz |= addr[i];
        nf |= (unsigned)(addr[i] ^ 0xffu);
    }
    return nz && nf &&
        !(addr[0] == 0x43 && addr[1] == 0x45 && addr[2] == 0xc0 &&
          addr[3] == 0 && addr[4] == 0x1f && addr[5] == 0xac);
}

/* Byte order of DT bluetooth local-bd-address is LITTLE ENDIAN. */
static void try_native_bd_addr(void)
{
    if (configured_bd_addr_valid || configured_bd_addr_bad) return;
    of_node_t *node = dt_find_node("/soc/serial@7e201000/bluetooth");
    if (!node) return;
    of_property_t *prop = dt_find_property(node, "local-bd-address");
    if (!prop || prop->op_length != 6u || !prop->op_value) return;
    const uint8_t *little = (const uint8_t *)prop->op_value;
    uint8_t candidate[6];
    for (unsigned i = 0; i < 6; ++i) candidate[i] = little[5-i];
    if (!valid_native_bd_addr(candidate)) return;
    memcpy(configured_bd_addr, candidate, 6);
    configured_bd_addr_valid = 1;
    configured_bd_addr_source = 2;
    kprintf("[BT-HCI] Device Tree local-bd-address selected\n");
}

#endif /* EMU68_BT_PAULA_POC7 */

#ifdef EMU68_BT_HCI_POC6
/* bt_bond=TYPE:32hex, no quotes, no whitespace, SSP types 4/5/7/8. */
static int parse_bond(const char *s, uint8_t key[16], unsigned *type)
{
    if (!s || (s[0] != '4' && s[0] != '5' && s[0] != '7' && s[0] != '8') ||
        s[1] != ':') return 0;
    *type = (unsigned)(s[0] - '0');
    s += 2;
    for (unsigned i = 0; i < 16; ++i) {
        if (s[0] == 0) return 0;
        int a = bt_hex(s[0]);
        if (a < 0 || s[1] == 0) return 0;
        int b = bt_hex(s[1]);
        if (b < 0) return 0;
        key[i] = (uint8_t)((a << 4) | b);
        s += 2;
    }
    if (*s != 0 && *s != ' ' && *s != '\t') return 0;
    unsigned nz = 0;
    for (unsigned i = 0; i < 16; ++i) nz |= key[i];
    return nz != 0;  /* Never preinstall an all-zero key. */
}

#endif /* EMU68_BT_HCI_POC6 */

static void bt_hci_parse_args(const char *args)
{
    if (!args)
        return;
#ifdef EMU68_BT_HCI_POC5
    if (find_token(args, "bt_hci_pair"))
        probe_mode = 5;
    else
#endif
#ifdef EMU68_BT_HCI_POC6
    if (find_token(args, "bt_hci_tone")) probe_mode = 6;
#endif
#ifdef EMU68_BT_PAULA_POC7
    /* Short mode alias to fit the firmware config.txt line limit. */
    if (find_token(args, "bt_hci_paula") || find_token(args, "paula_bt"))
        probe_mode = 7;
#endif
    if (probe_mode < 5 && find_token(args, "bt_hci_scan"))
        probe_mode = 4;
    else if (probe_mode < 4 && find_token(args, "bt_hci_patchram"))
        probe_mode = 3;
    else if (probe_mode < 3 && find_token(args, "bt_hci_probe"))
        probe_mode = 2;
    else if (probe_mode < 2 && find_token(args, "bt_hci_diag"))
        probe_mode = 1;
#ifdef EMU68_BT_HCI_POC5
    const char *peer = find_token(args, "bt_peer=");
    if (peer) {
        peer += sizeof("bt_peer=") - 1;
        if (parse_bd_addr(peer, configured_peer_addr))
            configured_peer_valid = 1;
        else
            configured_peer_bad = 1;
    }
#endif
    const char *address = find_token(args, "bt_bdaddr=");
    if (address) {
        address += sizeof("bt_bdaddr=") - 1;
        if (parse_bd_addr(address, configured_bd_addr)) {
            configured_bd_addr_valid = 1;
            configured_bd_addr_source = 1;
        }
        else
            configured_bd_addr_bad = 1;
    }
#ifdef EMU68_BT_HCI_POC6
    const char *bond = find_token(args, "bt_bond=");
    if (bond) {
        bond += sizeof("bt_bond=") - 1;
        configured_bond_valid = 0;
        configured_bond_bad = !parse_bond(bond, configured_bond_key,
                                           &configured_bond_type);
        if (!configured_bond_bad) configured_bond_valid = 1;
    }
#endif
#ifdef EMU68_BT_PAULA_POC7
    /* Strictly accept pal or ntsc, with a token boundary.  An omitted or
     * invalid value retains the proven PAL baseline.  /emu68/args is parsed
     * after /chosen/bootargs, so config.txt can override cmdline.txt. */
    const char *clock = find_token(args, "bt_paula_clock=");
    if (clock) {
        clock += sizeof("bt_paula_clock=") - 1;
        if (clock[0] == 'n' && clock[1] == 't' && clock[2] == 's' &&
            clock[3] == 'c' &&
            (clock[4] == 0 || clock[4] == ' ' || clock[4] == '\t')) {
            paula_clock_ntsc = 1u;
        } else if (clock[0] == 'p' && clock[1] == 'a' &&
                   clock[2] == 'l' &&
                   (clock[3] == 0 || clock[3] == ' ' || clock[3] == '\t')) {
            paula_clock_ntsc = 0u;
        } else {
            paula_clock_ntsc = 0u;
            kprintf("[BT-HCI] Invalid bt_paula_clock (expected pal or ntsc); using PAL\n");
        }
    }
#endif
}

void bt_hci_probe_prepare(void)
{
    of_node_t *chosen = dt_find_node("/chosen");
    if (chosen) {
        of_property_t *args = dt_find_property(chosen, "bootargs");
        if (args) {
            bt_hci_parse_args((const char *)args->op_value);
            /* This flag intentionally works ONLY in cmdline.txt. */
            bt_boot_pause_60s = bt_cmdline_has_pause((const char *)args->op_value);
        }
    }

    /* Preferred Emu68 1.1 configuration:
     * config.txt: dtoverlay=emu68,args=bt_hci_diag
     */
    of_node_t *emu = dt_find_node("/emu68");
    if (emu) {
        of_property_t *args = dt_find_property(emu, "args");
        if (args)
            bt_hci_parse_args((const char *)args->op_value);
    }

    if (!probe_mode)
        return;
    /* Explicit override takes precedence. The firmware's other disabled
     * mini-UART Bluetooth node contains six zeroes; never use it.
     */
#ifdef EMU68_BT_PAULA_POC7
    if (probe_mode == 7) try_native_bd_addr();
#endif

    if (probe_mode >= 2) {
        /* CPU0 before secondary CPUs: the existing mailbox buffer is shared. */
        uart_clock_hz = get_clock_rate(2);
    }

    kprintf("[BT-HCI] %s requested; PL011 clock %u Hz\n",
            probe_mode == 7 ? "A2DP Paula PCM" : probe_mode == 6 ? "A2DP SBC tone" : probe_mode == 5 ? "ACL+SSP pairing" :
             probe_mode == 4 ? "Classic inquiry" : probe_mode == 3 ? "PatchRAM" :
            probe_mode == 2 ? "active probe" : "read-only diagnostic",
            uart_clock_hz);
#ifdef EMU68_BT_PAULA_POC7
    if (probe_mode == 7u)
        kprintf("[BT-HCI] Paula clock: %s (%u Hz)\n",
                paula_clock_ntsc ? "NTSC" : "PAL",
                paula_clock_ntsc ? 3579545u : 3546895u);
#endif
}

static int uart_rx(uint8_t *byte, uint64_t deadline)
{
    while (before_deadline(deadline)) {
        uint32_t fr = rd32le(PL011_0_BASE + PL011_FR);
        if (!(fr & PL011_FR_RXFE)) {
            uint32_t v = rd32le(PL011_0_BASE + PL011_DR);
            if (v & 0xf00u) {
                /* PL011 reports overrun/framing/parity/break in DR[11:8]. */
                wr32le(PL011_0_BASE + PL011_RSRECR, 0u);
                return -2;
            }
            *byte = (uint8_t)v;
            return 0;
        }
        __asm__ volatile("yield");
    }
    return -1;
}

static int uart_tx(uint8_t byte, uint64_t deadline)
{
    while (before_deadline(deadline)) {
        if (!(rd32le(PL011_0_BASE + PL011_FR) & PL011_FR_TXFF)) {
            wr32le(PL011_0_BASE + PL011_DR, byte);
            return 0;
        }
        __asm__ volatile("yield");
    }
    return -1;
}

/* Discard stale H4 bytes before a command. Bound work even with a noisy UART. */
static unsigned drain_rx(void)
{
    unsigned n = 0;
    while (n < 256 && !(rd32le(PL011_0_BASE + PL011_FR) & PL011_FR_RXFE)) {
        (void)rd32le(PL011_0_BASE + PL011_DR);
        ++n;
    }
    return n;
}

/*
 * Read H4 Command Complete, ignoring unrelated HCI events. All receive loops
 * share one absolute deadline; a misbehaving device cannot lock CPU3.
 */
/* H4 command with parameters. One shared absolute deadline per receive frame.
 * Accept only matching Command Complete; discard asynchronous HCI events.
 * No interrupts, DMA, or unbounded waits on CPU3.
 */
static int hci_command_ex(uint16_t opcode, const uint8_t *data, unsigned ndata,
                          uint8_t *ret, unsigned *ret_len, unsigned timeout_ms)
{
    if (ndata > 255u) return -4;
    uint8_t hdr[4] = { HCI_COMMAND_PACKET, (uint8_t)opcode,
                       (uint8_t)(opcode >> 8), (uint8_t)ndata };
    uint64_t tx_deadline = counter_deadline_ms(700);
    for (unsigned i = 0; i < sizeof(hdr); ++i)
        if (uart_tx(hdr[i], tx_deadline)) return -1;
    for (unsigned i = 0; i < ndata; ++i)
        if (uart_tx(data[i], tx_deadline)) return -1;
    while (before_deadline(tx_deadline)) {
        if (!(rd32le(PL011_0_BASE + PL011_FR) & PL011_FR_BUSY)) break;
    }
    if (rd32le(PL011_0_BASE + PL011_FR) & PL011_FR_BUSY) return -2;

    uint64_t deadline = counter_deadline_ms(timeout_ms);
    unsigned scanned = 0;
    while (before_deadline(deadline) && scanned++ < 1024) {
        uint8_t type, code, n;
        int rc = uart_rx(&type, deadline);
        if (rc) return rc;
        if (type != HCI_EVENT_PACKET) continue;
        if ((rc = uart_rx(&code, deadline)) || (rc = uart_rx(&n, deadline)))
            return rc;
        uint8_t params[255];
        for (unsigned i = 0; i < n; ++i)
            if ((rc = uart_rx(&params[i], deadline))) return rc;
        if (code == HCI_EVENT_COMPLETE && n >= 4 &&
            params[1] == (uint8_t)opcode && params[2] == (uint8_t)(opcode >> 8)) {
            unsigned size = n - 3;
            if (size > *ret_len) return -3;
            for (unsigned i = 0; i < size; ++i) ret[i] = params[i + 3];
            *ret_len = size;
            return 0;
        }
    }
    return -1;
}

static int hci_command(uint16_t opcode, uint8_t *ret, unsigned *ret_len)
{
    return hci_command_ex(opcode, 0, 0, ret, ret_len, 1000);
}

#ifdef EMU68_BT_HCI_POC3
static void wait_ms(unsigned ms)
{
    uint64_t deadline = counter_deadline_ms(ms);
    while (before_deadline(deadline)) __asm__ volatile("yield");
}

/* POC3 runs at the proven 115200 baud; no baud switch / no Wi-Fi GPIO power.
 * Firmware is a series of LE16 HCI opcodes, u8 lengths and payloads.
 */
static void patchram_run(void)
{
    uint8_t r[255];
    unsigned len;
    int rc;
    const uint64_t total_deadline = counter_deadline_ms(60000);
    if (diag_page) {
        diag_page->fw_image_bytes = bt_bcm_patchram_len;
        diag_page->fw_records_total = bt_bcm_patchram_commands;
    }
    /* Abort on the wrong controller BEFORE issuing vendor commands. */
    if (!diag_page || diag_page->manufacturer != 15u ||
        diag_page->lmp_subversion != 0x6119u) {
        if (diag_page) diag_page->stop_reason = BTDIAG_STOP_FW_UNEXPECTED_CHIP;
        return;
    }
    len = sizeof(r);
    rc = hci_command(HCI_DOWNLOAD_OPCODE, r, &len);
    if (diag_page) {
        diag_page->fw_command_rc = rc;
        diag_page->fw_command_status = rc == 0 && len ? r[0] : 0xffu;
    }
    if (rc || len < 1 || r[0]) {
        if (diag_page) diag_page->stop_reason = BTDIAG_STOP_FW_MINIDRV_FAILED;
        return;
    }
    wait_ms(50);
    unsigned offset = 0;
    while (offset < bt_bcm_patchram_len) {
        if (!before_deadline(total_deadline)) {
            if (diag_page) diag_page->stop_reason = BTDIAG_STOP_FW_BUDGET;
            return;
        }
        if (bt_bcm_patchram_len - offset < 3u) {
            if (diag_page) diag_page->stop_reason = BTDIAG_STOP_FW_CORRUPT;
            return;
        }
        uint16_t opcode = (uint16_t)bt_bcm_patchram[offset] |
                          ((uint16_t)bt_bcm_patchram[offset + 1] << 8);
        unsigned count = bt_bcm_patchram[offset + 2];
        if (count > bt_bcm_patchram_len - offset - 3u) {
            if (diag_page) diag_page->stop_reason = BTDIAG_STOP_FW_CORRUPT;
            return;
        }
        if (diag_page) {
            diag_page->fw_failed_opcode = opcode;
            diag_page->fw_failed_offset = offset;
        }
        /* Some HCDs repeat Download MiniDriver. BTstack explicitly skips it. */
        if (opcode != HCI_DOWNLOAD_OPCODE) {
            len = sizeof(r);
            rc = hci_command_ex(opcode, &bt_bcm_patchram[offset + 3],
                                count, r, &len, 1500);
            if (diag_page) {
                diag_page->fw_command_rc = rc;
                diag_page->fw_command_status = rc == 0 && len ? r[0] : 0xffu;
            }
            if (rc || len < 1 || r[0]) {
                if (diag_page) diag_page->stop_reason = BTDIAG_STOP_FW_RECORD_FAILED;
                return;
            }
        }
        offset += 3u + count;
        if (diag_page) ++diag_page->fw_records_sent;
    }
    wait_ms(250);
    drain_rx();
    len = sizeof(r);
    rc = hci_command(HCI_RESET_OPCODE, r, &len);
    if (diag_page) {
        diag_page->fw_command_rc = rc;
        diag_page->fw_command_status = rc == 0 && len ? r[0] : 0xffu;
    }
    if (rc || len < 1 || r[0]) {
        if (diag_page) diag_page->stop_reason = BTDIAG_STOP_FW_POSTRESET_FAILED;
        return;
    }
    wait_ms(100);
    len = sizeof(r);
    rc = hci_command(HCI_VERSION_OPCODE, r, &len);
    if (diag_page) {
        diag_page->fw_command_rc = rc;
        diag_page->fw_command_status = rc == 0 && len ? r[0] : 0xffu;
    }
    if (rc || len < 9 || r[0]) {
        if (diag_page) diag_page->stop_reason = BTDIAG_STOP_FW_POSTVERSION_FAILED;
        return;
    }
    if (diag_page) {
        diag_page->post_hci_version = r[1];
        diag_page->post_hci_revision = (uint32_t)r[2] | ((uint32_t)r[3] << 8);
        diag_page->post_lmp_version = r[4];
        diag_page->post_manufacturer = (uint32_t)r[5] | ((uint32_t)r[6] << 8);
        diag_page->post_lmp_subversion = (uint32_t)r[7] | ((uint32_t)r[8] << 8);
    }
    len = sizeof(r);
    rc = hci_command(HCI_BDADDR_OPCODE, r, &len);
    if (rc == 0 && len >= 7u && r[0] == 0 && diag_page) {
        /* HCI sends addresses least-significant octet first. */
        diag_page->bd_addr_hi = ((uint32_t)r[6] << 8) | r[5];
        diag_page->bd_addr_lo = ((uint32_t)r[4] << 24) |
            ((uint32_t)r[3] << 16) | ((uint32_t)r[2] << 8) | r[1];
        diag_page->bd_addr_valid = 1;
    }
    if (diag_page) diag_page->stop_reason = BTDIAG_STOP_FW_SUCCESS;
}

#ifdef EMU68_BT_HCI_POC4
/* A single HCI packet type 0x04 is followed by event code, length and payload.
 * The scan command produces Command Status + asynchronous inquiry results,
 * unlike normal HCI commands, which return Command Complete.
 */
static int hci_send_async(uint16_t opcode, const uint8_t *data, unsigned ndata)
{
    if (ndata > 255u) return -4;
    uint8_t hdr[4] = { HCI_COMMAND_PACKET, (uint8_t)opcode,
                       (uint8_t)(opcode >> 8), (uint8_t)ndata };
    uint64_t deadline = counter_deadline_ms(1000);
    for (unsigned i = 0; i < sizeof(hdr); ++i)
        if (uart_tx(hdr[i], deadline)) return -1;
    for (unsigned i = 0; i < ndata; ++i)
        if (uart_tx(data[i], deadline)) return -1;
    while (before_deadline(deadline)) {
        if (!(rd32le(PL011_0_BASE + PL011_FR) & PL011_FR_BUSY)) return 0;
    }
    return -2;
}

/* Endian-independent: all on-wire HCI parameter bytes are explicitly LE. */
static int set_uart_host_baud(uint32_t baud)
{
    uint64_t scaled = ((uint64_t)uart_clock_hz * 4u + baud / 2u) / baud;
    uint32_t ibrd = (uint32_t)(scaled >> 6);
    uint32_t fbrd = (uint32_t)(scaled & 63u);
    if (ibrd == 0 || ibrd > 65535) return -1;
    wr32le(PL011_0_BASE + PL011_CR, 0);
    wr32le(PL011_0_BASE + PL011_IBRD, ibrd);
    wr32le(PL011_0_BASE + PL011_FBRD, fbrd);
    wr32le(PL011_0_BASE + PL011_LCRH, PL011_LCRH_WLEN8 | PL011_LCRH_FEN);
    wr32le(PL011_0_BASE + PL011_CR,
           PL011_CR_UARTEN | PL011_CR_TXE | PL011_CR_RXE |
           PL011_CR_RTSEN | PL011_CR_CTSEN);
    dsb();
    if (diag_page) {
        diag_page->uart_ibrd = ibrd;
        diag_page->uart_fbrd = fbrd;
        diag_page->scan_uart_baud = baud;
    }
    return 0;
}

static int hci_read_event(uint8_t *code, uint8_t *params, unsigned *n,
                          uint64_t deadline)
{
    uint8_t type = 0, len = 0;
    int rc;
    do {
        rc = uart_rx(&type, deadline);
        if (rc) return rc;
    } while (type != HCI_EVENT_PACKET);
    if ((rc = uart_rx(code, deadline)) || (rc = uart_rx(&len, deadline)))
        return rc;
    *n = len;
    for (unsigned i = 0; i < len; ++i)
        if ((rc = uart_rx(&params[i], deadline))) return rc;
    return 0;
}

static void scan_add_device(const uint8_t *address_le, uint32_t cod,
                            int rssi, int have_rssi,
                            const uint8_t *eir, unsigned eir_len)
{
    if (!diag_page) return;
    unsigned idx;
    /* Bluetooth event and HCI transport order is LSB-first. */
    for (idx = 0; idx < diag_page->scan_count; ++idx) {
        unsigned k;
        for (k = 0; k < 6; ++k)
            if (diag_page->devices[idx].address[k] != address_le[5-k]) break;
        if (k == 6) return;
    }
    if (idx >= BTDIAG_MAX_DEVICES) return;
    volatile struct bt_hci_scan_device *dev = &diag_page->devices[idx];
    for (unsigned k = 0; k < 6; ++k)
        dev->address[k] = address_le[5-k];
    dev->class_of_device = cod;
    if (have_rssi) {
        dev->rssi = (int8_t)rssi;
        dev->flags |= 1u;
    }
    /* EIR is a set of bounded TLV fields. Prefer complete name (0x09). */
    for (unsigned pos = 0; pos < eir_len;) {
        unsigned length = eir[pos++];
        if (!length || length > eir_len - pos) break;
        unsigned type = eir[pos];
        if (type == 0x09 || (type == 0x08 && !(dev->flags & 2u))) {
            unsigned copy = length - 1;
            if (copy > sizeof(dev->name) - 1) copy = sizeof(dev->name) - 1;
            for (unsigned j = 0; j < copy; ++j) {
                uint8_t ch = eir[pos + 1 + j];
                dev->name[j] = (ch >= 32 && ch <= 126) ? ch : '_';
            }
            dev->name[copy] = 0;
            dev->flags |= 2u;
            if (type == 0x09) break;
        }
        pos += length;
    }
    diag_page->scan_count = idx + 1;
}

static int scan_inquiry(void)
{
    uint8_t r[255];
    unsigned n = sizeof(r);
    /* After HCI Reset the event mask defaults to 0x00001fffffffffff:
     * Extended Inquiry Result (event 0x2f, bit 46) is DISABLED.
     * POC4 selected inquiry mode 2 but never enabled event 0x2f: the radio
     * could find devices while the host received only Inquiry Complete.
     * Enable that event explicitly; retain the other default event bits.
     * Little-endian mask 0x00005fffffffffff. If rejected, use RSSI mode 1,
     * whose event 0x22 is enabled by the standard default mask.
     */
    const uint8_t event_mask[8] = {0xff, 0xff, 0xff, 0xff,
                                   0xff, 0x5f, 0x00, 0x00};
    int rc = hci_command_ex(HCI_SET_EVENT_MASK, event_mask,
                            sizeof(event_mask), r, &n, 1500);
    int eir_enabled = (rc == 0 && n >= 1u && r[0] == 0);
    uint8_t mode = eir_enabled ? 2u : 1u;
    n = sizeof(r);
    rc = hci_command_ex(HCI_INQUIRY_MODE, &mode, 1, r, &n, 1500);
    if (rc || n < 1 || r[0]) {
        mode = (mode == 2u) ? 1u : 0u;
        n = sizeof(r);
        rc = hci_command_ex(HCI_INQUIRY_MODE, &mode, 1, r, &n, 1500);
        if (rc || n < 1 || r[0]) mode = 0u;
    }
    if (diag_page) diag_page->scan_mode = mode;

    /* GIAC = 0x9E8B33; length 0x08 = 10.24 seconds; unlimited results. */
    const uint8_t cmd[5] = {0x33, 0x8b, 0x9e, 0x08, 0x00};
    if (hci_send_async(HCI_INQUIRY_OPCODE, cmd, sizeof(cmd))) return -1;
    uint64_t deadline = counter_deadline_ms(14000);
    unsigned status_seen = 0;
    while (before_deadline(deadline)) {
        uint8_t event_code;
        unsigned plen = 0;
        rc = hci_read_event(&event_code, r, &plen, deadline);
        if (rc) return -2;
        if (event_code == 0x0f && plen >= 4 &&
            r[2] == (uint8_t)HCI_INQUIRY_OPCODE &&
            r[3] == (uint8_t)(HCI_INQUIRY_OPCODE >> 8)) {
            if (r[0]) return -(int)r[0] - 100;
            status_seen = 1;
            continue;
        }
        if (event_code == 0x01 && plen >= 1) {
            if (diag_page) diag_page->scan_complete = 1;
            return r[0] ? -(int)r[0] - 200 : 0;
        }
        if ((event_code == 0x02 || event_code == 0x22 || event_code == 0x2f) && plen >= 7) {
            unsigned responses = r[0];
            /* Extended inquiry results always describe one peer. */
            if (event_code == 0x2f && responses == 1 && plen >= 15) {
                uint32_t cod = (uint32_t)r[9] | ((uint32_t)r[10] << 8) |
                               ((uint32_t)r[11] << 16);
                scan_add_device(r + 1, cod, (int8_t)r[14], 1,
                                r + 15, plen - 15);
            } else if ((event_code == 0x02 || event_code == 0x22) && responses) {
                /* Inquiry Result/RSSI fields are arrays. Never assume N=1. */
                unsigned needed = 1u + responses * 14u;
                if (plen < needed) continue;
                for (unsigned i = 0; i < responses; ++i) {
                    /* BTstack's gap_inquiry_explode() field-array layout:
                     * legacy Inquiry Result has two reserved bytes,
                     * RSSI Inquiry Result has one reserved byte.
                     * Both have 14 bytes per response.
                     */
                    unsigned reserved = event_code == 0x02 ? 2u : 1u;
                    unsigned cod_offset = 1u + responses * (7u + reserved) + 3u * i;
                    unsigned rssi_offset = 1u + responses * 13u + i;
                    if (cod_offset + 3 > plen) break;
                    uint32_t cod = (uint32_t)r[cod_offset] |
                                   ((uint32_t)r[cod_offset+1] << 8) |
                                   ((uint32_t)r[cod_offset+2] << 16);
                    int has_rssi = event_code == 0x22 && rssi_offset < plen;
                    scan_add_device(r + 1u + 6u * i, cod,
                                    has_rssi ? (int8_t)r[rssi_offset] : 0,
                                    has_rssi, 0, 0);
                }
            }
        }
    }
    return status_seen ? -3 : -4;
}

static int read_public_addr(void)
{
    uint8_t r[20];
    unsigned n = sizeof(r);
    int rc = hci_command(HCI_BDADDR_OPCODE, r, &n);
    if (rc || n < 7 || r[0]) return -1;
    if (diag_page) {
        diag_page->bd_addr_hi = ((uint32_t)r[6] << 8) | r[5];
        diag_page->bd_addr_lo = ((uint32_t)r[4] << 24) |
            ((uint32_t)r[3] << 16) | ((uint32_t)r[2] << 8) | r[1];
        diag_page->bd_addr_valid = 1;
    }
    return 0;
}

/* CPU3 bootstrap mode: initialized PatchRAM + baud, no A2DP peer yet.
 * Requests only come from the mapped Amiga command page.
 */
static void poc8_scan_wait(void)
{
    if (!control_page || !diag_page) return;
    diag_page->stop_reason = BTDIAG_STOP_FW_SUCCESS;
    unsigned last = control_page->completed_seq;
    for (;;) {
        uint32_t seq = control_page->request_seq;
        if (seq != last) {
            last = seq;
            uint32_t command = control_page->command;
            control_page->result = 0;
            if (command == BTCTRL_SCAN) {
                diag_page->scan_count = 0;
                diag_page->scan_complete = 0;
                diag_page->scan_mode = 0xffffffffu;
                diag_page->scan_rc = -1;
                memset((void *)diag_page->devices, 0, sizeof(diag_page->devices));
                int rc = scan_inquiry();
                diag_page->scan_rc = rc;
                diag_page->stop_reason = rc == 0 ? BTDIAG_STOP_INQUIRY_OK :
                                           BTDIAG_STOP_INQUIRY_FAILED;
                control_page->result = rc == 0 ? BTCTRL_OK : BTCTRL_FAILED;
            } else {
                control_page->result = BTCTRL_BAD_MODE;
            }
            dsb();
            control_page->completed_seq = seq;
            dsb();
        }
        /* Dedicated CPU3 polling, no interrupts or new scheduler. */
        wait_ms(5);
    }
}

static void poc4_run(int do_inquiry)
{
    if (!diag_page) return;
    uint8_t result[24];
    unsigned n;
    int rc;
    if (configured_bd_addr_bad) {
        diag_page->stop_reason = BTDIAG_STOP_BAD_ADDRESS;
        return;
    }
    if (configured_bd_addr_valid) {
        uint8_t addr_le[6];
        for (unsigned i = 0; i < 6; ++i) addr_le[i] = configured_bd_addr[5-i];
        n = sizeof(result);
        rc = hci_command_ex(HCI_BCM_SET_BDADDR, addr_le, sizeof(addr_le),
                            result, &n, 1500);
        if (rc || n < 1 || result[0]) {
            diag_page->stop_reason = BTDIAG_STOP_SET_ADDRESS_FAILED;
            return;
        }
        diag_page->address_config_state = 2;
        if (read_public_addr() ||
            diag_page->bd_addr_hi != ((uint32_t)configured_bd_addr[0] << 8 |
                                      configured_bd_addr[1]) ||
            diag_page->bd_addr_lo != ((uint32_t)configured_bd_addr[2] << 24 |
                                      (uint32_t)configured_bd_addr[3] << 16 |
                                      (uint32_t)configured_bd_addr[4] << 8 |
                                      configured_bd_addr[5])) {
            diag_page->stop_reason = BTDIAG_STOP_SET_ADDRESS_FAILED;
            return;
        }
    }
    /* BCM vendor Update UART Baud Rate: 2 zero bytes, LE32 baud. */
    const uint8_t baud[6] = {0,0,0x00,0x10,0x0e,0x00};
    n = sizeof(result);
    rc = hci_command_ex(HCI_BCM_SET_BAUD, baud, sizeof(baud),
                        result, &n, 1500);
    if (rc || n < 1 || result[0]) {
        diag_page->stop_reason = BTDIAG_STOP_BAUD_COMMAND_FAILED;
        return;
    }
    /* The controller has switched rate; from now on NEVER restore only the
     * host UART snapshot. Keep host/controller synchronized until reboot. */
    if (set_uart_host_baud(921600)) {
        diag_page->stop_reason = BTDIAG_STOP_BAUD_HOST_FAILED;
        return;
    }
    diag_page->uart_owned = 1;
    wait_ms(30);
    drain_rx();
    n = sizeof(result);
    rc = hci_command(HCI_VERSION_OPCODE, result, &n);
    if (rc || n < 9 || result[0]) {
        diag_page->stop_reason = BTDIAG_STOP_BAUD_VERIFY_FAILED;
        return;
    }
    diag_page->baud_verified = 1;
    if (read_public_addr()) {
        diag_page->stop_reason = BTDIAG_STOP_SET_ADDRESS_FAILED;
        return;
    }
    if (!do_inquiry) return; /* POC5: keep proven PatchRAM+baud path, no scan */
    rc = scan_inquiry();
    diag_page->scan_rc = rc;
    diag_page->stop_reason = rc == 0 ? BTDIAG_STOP_INQUIRY_OK :
                              BTDIAG_STOP_INQUIRY_FAILED;
}

#ifdef EMU68_BT_HCI_POC5
/* POC5: direct HCI-only Classic baseband and SSP Just Works validation.
 * No L2CAP, SDP, AVRCP or A2DP. One explicit peer, one boot-time attempt.
 * All link-key material stays in private ARM RAM and is lost on reboot.
 */
#define P5_CREATE_CONNECTION  0x0405u
#define P5_DISCONNECT         0x0406u
#define P5_LINK_KEY_REPLY     0x040bu
#define P5_LINK_KEY_NEGATIVE  0x040cu
#define P5_PIN_NEGATIVE       0x040eu
#define P5_AUTH_REQUESTED     0x0411u
#define P5_ENCRYPT_REQUESTED  0x0413u
#define P5_IO_CAP_REPLY       0x042bu
#define P5_CONFIRM_REPLY      0x042cu
#define P5_PASSKEY_NEGATIVE   0x042fu
#define P5_OOB_NEGATIVE       0x0433u
#define P5_WRITE_SSP_MODE     0x0c56u

static uint16_t p5_connection_handle;
static unsigned p5_have_handle;
static unsigned p5_authenticated;
static unsigned p5_encrypted;
static unsigned p5_legacy_pin_seen;

static int p5_peer_matches(const uint8_t *hci_little_endian)
{
    for (unsigned i = 0; i < 6; ++i)
        if (hci_little_endian[i] != configured_peer_addr[5-i]) return 0;
    return 1;
}
static void p5_target_little_endian(uint8_t addr[6])
{
    for (unsigned i = 0; i < 6; ++i)
        addr[i] = configured_peer_addr[5-i];
}

/* Consume entire non-event H4 packets. Otherwise ACL payload bytes could be
 * mistaken for HCI event headers during or immediately after authentication. */
static int p5_read_event(uint8_t *event, uint8_t p[255], unsigned *plen,
                         uint64_t deadline)
{
    while (before_deadline(deadline)) {
        uint8_t type, a, b, c, d;
        if (uart_rx(&type, deadline)) return -1;
        if (type == HCI_EVENT_PACKET) {
            if (uart_rx(event, deadline) || uart_rx(&a, deadline)) return -1;
            *plen = a;
            for (unsigned i = 0; i < *plen; ++i)
                if (uart_rx(&p[i], deadline)) return -1;
            return 0;
        }
        unsigned length;
        if (type == 0x02) { /* ACL data: handle LE16, length LE16 */
            if (uart_rx(&a, deadline) || uart_rx(&b, deadline) ||
                uart_rx(&c, deadline) || uart_rx(&d, deadline)) return -1;
            length = (unsigned)c | ((unsigned)d << 8);
        } else if (type == 0x03) { /* SCO: handle LE16, length u8 */
            if (uart_rx(&a, deadline) || uart_rx(&b, deadline) ||
                uart_rx(&c, deadline)) return -1;
            length = c;
        } else if (type == 0x05) { /* ISO: handle LE16, length LE16 */
            if (uart_rx(&a, deadline) || uart_rx(&b, deadline) ||
                uart_rx(&c, deadline) || uart_rx(&d, deadline)) return -1;
            length = ((unsigned)c | ((unsigned)d << 8)) & 0x3fffu;
        } else {
            return -2; /* unknown H4 packet: cannot resynchronize safely */
        }
        if (length > 4096u) return -3;
        for (unsigned i = 0; i < length; ++i)
            if (uart_rx(&a, deadline)) return -1;
    }
    return -1;
}

static int p5_send(uint16_t opcode, const uint8_t *payload, unsigned n)
{
    if (diag_page) diag_page->pair_last_opcode = opcode;
    return hci_send_async(opcode, payload, n);
}

static int p5_send_to_peer(uint16_t opcode)
{
    uint8_t peer[6];
    p5_target_little_endian(peer);
    return p5_send(opcode, peer, 6);
}

static void p5_disconnect(void)
{
    if (!p5_have_handle) return;
    uint8_t payload[3] = { (uint8_t)p5_connection_handle,
                           (uint8_t)(p5_connection_handle >> 8), 0x13 };
    /* Remote User Terminated Connection; bounded wait for event. */
    if (p5_send(P5_DISCONNECT, payload, 3)) return;
    uint64_t until = counter_deadline_ms(2500);
    uint8_t code, data[255];
    unsigned n;
    while (before_deadline(until)) {
        if (p5_read_event(&code, data, &n, until)) break;
        if (code == 0x05 && n >= 4 &&
            (data[1] | (data[2] << 8)) == p5_connection_handle) {
            if (diag_page) {
                diag_page->pair_disconnected = 1u;
                diag_page->pair_disconnect_status = data[0];
            }
            break;
        }
    }
}

static void p5_run(void)
{
    if (!diag_page) return;
    if (configured_peer_bad || !configured_peer_valid) {
        diag_page->stop_reason = BTDIAG_STOP_PAIR_BAD_PEER;
        return;
    }
    if (!configured_bd_addr_valid || configured_bd_addr_bad) {
        diag_page->stop_reason = BTDIAG_STOP_PAIR_MISSING_ADDR;
        return;
    }
    if (!diag_page->baud_verified || !diag_page->uart_owned ||
        diag_page->address_config_state != 2u) {
        diag_page->stop_reason = BTDIAG_STOP_PAIR_SETUP_FAILED;
        return;
    }
    /* NoInputNoOutput means Just Works pairing with no MITM protection.
     * Restricted to the specific bt_peer explicitly requested by the user.
     * Do not enable incoming Page Scan or general discoverability.
     */
    const uint8_t event_mask[8] =
        { 0xff, 0xff, 0xff, 0xff, 0xff, 0x5f, 0x3f, 0x00 };
    uint8_t reply[255], ssp = 1;
    unsigned n = sizeof(reply);
    int rc = hci_command_ex(HCI_SET_EVENT_MASK, event_mask,
                            sizeof(event_mask), reply, &n, 1500);
    if (rc || n < 1 || reply[0]) {
        diag_page->stop_reason = BTDIAG_STOP_PAIR_SETUP_FAILED;
        return;
    }
    n = sizeof(reply);
    rc = hci_command_ex(P5_WRITE_SSP_MODE, &ssp, 1, reply, &n, 1500);
    if (rc || n < 1 || reply[0]) {
        diag_page->stop_reason = BTDIAG_STOP_PAIR_SETUP_FAILED;
        return;
    }

    uint8_t connect[13] = {0};
    p5_target_little_endian(connect);
    connect[6] = 0x18; connect[7] = 0xcc; /* packet type 0xCC18 */
    connect[8] = 0x01;  /* R1 page scan repetition, without inquiry metadata */
    connect[9] = 0x00;  /* reserved */
    connect[10] = connect[11] = 0; /* unknown clock offset */
    connect[12] = 0x01; /* allow role switch */
    if (p5_send(P5_CREATE_CONNECTION, connect, sizeof(connect))) {
        diag_page->stop_reason = BTDIAG_STOP_PAIR_CREATE_FAILED;
        return;
    }

    uint64_t began = counter_now();
    uint64_t until = counter_deadline_ms(45000);
    diag_page->stop_reason = BTDIAG_STOP_PAIR_TIMEOUT;
    p5_connection_handle = 0;
    p5_have_handle = 0;
    p5_authenticated = 0;
    p5_encrypted = 0;
    p5_legacy_pin_seen = 0;
    pair_key_valid = 0;

    while (before_deadline(until)) {
        uint8_t code, data[255];
        unsigned length = 0;
        int err = p5_read_event(&code, data, &length, until);
        if (err) {
            diag_page->stop_reason = before_deadline(until) ?
                BTDIAG_STOP_PAIR_EVENT_FAILED : BTDIAG_STOP_PAIR_TIMEOUT;
            break;
        }
        diag_page->pair_last_event = code;

        if (code == 0x0f && length >= 4) { /* Command Status */
            uint16_t opcode = (uint16_t)data[2] | ((uint16_t)data[3] << 8);
            if (data[0]) {
                diag_page->pair_last_opcode = opcode;
                diag_page->pair_last_status = data[0];
                diag_page->stop_reason = opcode == P5_CREATE_CONNECTION ?
                    BTDIAG_STOP_PAIR_CREATE_FAILED : BTDIAG_STOP_PAIR_EVENT_FAILED;
                break;
            }
            continue;
        }
        if (code == 0x0e && length >= 4) { /* Command Complete */
            uint16_t opcode = (uint16_t)data[1] | ((uint16_t)data[2] << 8);
            if (data[3]) {
                diag_page->pair_last_opcode = opcode;
                diag_page->pair_last_status = data[3];
                diag_page->stop_reason = BTDIAG_STOP_PAIR_EVENT_FAILED;
                break;
            }
            continue;
        }
        if (code == 0x03 && length >= 11 && p5_peer_matches(data + 3)) {
            diag_page->pair_connection_status = data[0];
            if (data[0] || data[9] != 1) {
                diag_page->stop_reason = BTDIAG_STOP_PAIR_CONNECTION_FAILED;
                break;
            }
            p5_connection_handle = (uint16_t)data[1] |
                                   ((uint16_t)data[2] << 8);
            p5_have_handle = 1;
            diag_page->pair_handle = p5_connection_handle;
            diag_page->pair_acl_connected = 1;
            uint8_t params[2] = { (uint8_t)p5_connection_handle,
                                  (uint8_t)(p5_connection_handle >> 8) };
            if (p5_send(P5_AUTH_REQUESTED, params, 2)) {
                diag_page->stop_reason = BTDIAG_STOP_PAIR_EVENT_FAILED;
                break;
            }
            continue;
        }
        if (code == 0x17 && length >= 6 && p5_peer_matches(data)) {
            ++diag_page->pair_key_requests;
            if (pair_key_valid) {
                uint8_t params[22];
                p5_target_little_endian(params);
                for (unsigned i = 0; i < 16; ++i)
                    params[6+i] = pair_link_key[i];
                if (p5_send(P5_LINK_KEY_REPLY, params, sizeof(params))) {
                    diag_page->stop_reason = BTDIAG_STOP_PAIR_EVENT_FAILED; break;
                }
            } else if (p5_send_to_peer(P5_LINK_KEY_NEGATIVE)) {
                diag_page->stop_reason = BTDIAG_STOP_PAIR_EVENT_FAILED; break;
            }
            continue;
        }
        if (code == 0x31 && length >= 6 && p5_peer_matches(data)) {
            ++diag_page->pair_io_capability_requests;
            uint8_t params[9];
            p5_target_little_endian(params);
            params[6] = 0x03; /* no input/no output */
            params[7] = 0x00; /* no OOB */
            params[8] = 0x04; /* general bonding, no MITM */
            if (p5_send(P5_IO_CAP_REPLY, params, sizeof(params))) {
                diag_page->stop_reason = BTDIAG_STOP_PAIR_EVENT_FAILED; break;
            }
            continue;
        }
        if (code == 0x33 && length >= 10 && p5_peer_matches(data)) {
            ++diag_page->pair_confirmation_requests;
            /* Just Works: no numeric confirmation possible in this POC. */
            if (p5_send_to_peer(P5_CONFIRM_REPLY)) {
                diag_page->stop_reason = BTDIAG_STOP_PAIR_EVENT_FAILED; break;
            }
            continue;
        }
        if (code == 0x16 && length >= 6 && p5_peer_matches(data)) {
            ++diag_page->pair_legacy_pin_requests;
            p5_legacy_pin_seen = 1;
            if (p5_send_to_peer(P5_PIN_NEGATIVE)) {
                diag_page->stop_reason = BTDIAG_STOP_PAIR_EVENT_FAILED; break;
            }
            continue;
        }
        if (code == 0x34 && length >= 6 && p5_peer_matches(data)) {
            if (p5_send_to_peer(P5_PASSKEY_NEGATIVE)) {
                diag_page->stop_reason = BTDIAG_STOP_PAIR_EVENT_FAILED; break;
            }
            continue;
        }
        if (code == 0x35 && length >= 6 && p5_peer_matches(data)) {
            if (p5_send_to_peer(P5_OOB_NEGATIVE)) {
                diag_page->stop_reason = BTDIAG_STOP_PAIR_EVENT_FAILED; break;
            }
            continue;
        }
        if (code == 0x18 && length >= 23 && p5_peer_matches(data)) {
            for (unsigned i = 0; i < 16; ++i)
                pair_link_key[i] = data[6+i];
            pair_key_valid = 1;
            diag_page->pair_link_key_seen = 1;
            continue;
        }
        if (code == 0x36 && length >= 7 && p5_peer_matches(data+1)) {
            diag_page->pair_ssp_complete = data[0] == 0;
            if (data[0]) {
                diag_page->pair_auth_status = data[0];
                diag_page->stop_reason = BTDIAG_STOP_PAIR_AUTH_FAILED;
                break;
            }
            continue;
        }
        if (code == 0x06 && length >= 3 &&
            ((uint16_t)data[1] | ((uint16_t)data[2] << 8)) ==
                p5_connection_handle && p5_have_handle) {
            diag_page->pair_auth_status = data[0];
            if (data[0]) {
                diag_page->stop_reason = p5_legacy_pin_seen ?
                    BTDIAG_STOP_PAIR_LEGACY_UNSUPPORTED :
                    BTDIAG_STOP_PAIR_AUTH_FAILED;
                break;
            }
            p5_authenticated = 1;
            diag_page->pair_authenticated = 1;
            uint8_t enc[3] = { (uint8_t)p5_connection_handle,
                               (uint8_t)(p5_connection_handle >> 8), 1 };
            if (p5_send(P5_ENCRYPT_REQUESTED, enc, sizeof(enc))) {
                diag_page->stop_reason = BTDIAG_STOP_PAIR_EVENT_FAILED; break;
            }
            continue;
        }
        if (code == 0x08 && length >= 4 &&
            ((uint16_t)data[1] | ((uint16_t)data[2] << 8)) ==
                p5_connection_handle && p5_have_handle) {
            diag_page->pair_encryption_status = data[0];
            if (data[0]) {
                diag_page->stop_reason = BTDIAG_STOP_PAIR_ENCRYPT_FAILED;
                break;
            }
            if (data[3]) {
                p5_encrypted = 1;
                diag_page->pair_encrypted = 1;
                if (p5_authenticated) {
                    diag_page->stop_reason = BTDIAG_STOP_PAIR_SUCCESS;
                    break;
                }
            }
            continue;
        }
        if (code == 0x05 && length >= 4 &&
            ((uint16_t)data[1] | ((uint16_t)data[2] << 8)) ==
                p5_connection_handle && p5_have_handle) {
            diag_page->pair_disconnected = 1;
            diag_page->pair_disconnect_status = data[0];
            diag_page->stop_reason = BTDIAG_STOP_PAIR_CONNECTION_FAILED;
            p5_have_handle = 0;
            break;
        }
    }

    uint64_t frq;
    __asm__ volatile("mrs %0, CNTFRQ_EL0" : "=r"(frq));
    if (frq)
        diag_page->pair_elapsed_ms =
            (uint32_t)(((counter_now() - began) * 1000u) / frq);
    /* Detach cleanly, retaining only a RAM link key until the next boot.
     * A2DP will require a persistent controller and later link-key storage. */
    p5_disconnect();
}
#endif /* EMU68_BT_HCI_POC5 */

#endif /* EMU68_BT_HCI_POC4 */
#endif

struct uart_snapshot {
    uint32_t fsel3;
    uint32_t cr;
    uint32_t ibrd;
    uint32_t fbrd;
    uint32_t lcrh;
    uint32_t imsc;
    uint32_t ifls;
};

static void restore_uart(const struct uart_snapshot *old)
{
    /* Never leave a failed diagnostic owning UART0 or GPIO30-33. */
    wr32le(PL011_0_BASE + PL011_CR, 0);
    wr32le(PL011_0_BASE + PL011_IBRD, old->ibrd);
    wr32le(PL011_0_BASE + PL011_FBRD, old->fbrd);
    wr32le(PL011_0_BASE + PL011_LCRH, old->lcrh);
    wr32le(PL011_0_BASE + PL011_IFLS, old->ifls);
    wr32le(PL011_0_BASE + PL011_IMSC, old->imsc);
    wr32le(PL011_0_BASE + PL011_CR, old->cr);
    wr32le(GPIO_GPFSEL3, old->fsel3);
    dsb();
    diag_restored();
}

static void probe_active(uint32_t fsel3, uint32_t fsel4, uint32_t clock_ctl)
{
    if (!uart_clock_hz || uart_clock_hz < 1000000u) {
        if (diag_page) diag_page->stop_reason = BTDIAG_STOP_NO_CLOCK;
        kprintf("[BT-HCI] STOP: invalid UART clock; no registers changed\n");
        return;
    }
    if (gpio_function(fsel4, 43) != GPIO_FSEL_ALT0 ||
        (clock_ctl & ((1u << 4) | (1u << 7))) != ((1u << 4) | (1u << 7))) {
        if (diag_page) diag_page->stop_reason = BTDIAG_STOP_BAD_GPCLK2;
        kprintf("[BT-HCI] STOP: GPCLK2 on GPIO43 GPCLK2 disabled/not running; no registers changed\n");
        return;
    }

    struct uart_snapshot old = {
        .fsel3 = fsel3,
        .cr = rd32le(PL011_0_BASE + PL011_CR),
        .ibrd = rd32le(PL011_0_BASE + PL011_IBRD),
        .fbrd = rd32le(PL011_0_BASE + PL011_FBRD),
        .lcrh = rd32le(PL011_0_BASE + PL011_LCRH),
        .imsc = rd32le(PL011_0_BASE + PL011_IMSC),
        .ifls = rd32le(PL011_0_BASE + PL011_IFLS)
    };

    /* Pi 3A+ internal connection: GPIO30..33 ALT3 = UART0 CTS/RTS/TX/RX. */
    uint32_t bits = 0;
    for (unsigned gpio = 30; gpio <= 33; ++gpio)
        bits |= (7u << ((gpio - 30u) * 3u));
    uint32_t pins = fsel3 & ~bits;
    for (unsigned gpio = 30; gpio <= 33; ++gpio)
        pins |= GPIO_FSEL_ALT3 << ((gpio - 30u) * 3u);

    uint64_t scaled = ((uint64_t)uart_clock_hz * 4u + 57600u) / 115200u;
    uint32_t integer = (uint32_t)(scaled >> 6);
    uint32_t fractional = (uint32_t)(scaled & 63u);
    if (integer == 0 || integer > 65535u) {
        if (diag_page) diag_page->stop_reason = BTDIAG_STOP_BAD_DIVISOR;
        kprintf("[BT-HCI] STOP: UART divisor out of range; no registers changed\n");
        return;
    }

    wr32le(PL011_0_BASE + PL011_CR, 0u);
    wr32le(GPIO_GPFSEL3, pins);
    wr32le(PL011_0_BASE + PL011_IMSC, PL011_IMSC_ALL);
    wr32le(PL011_0_BASE + PL011_ICR, PL011_ICR_ALL);
    wr32le(PL011_0_BASE + PL011_RSRECR, 0u);
    wr32le(PL011_0_BASE + PL011_IBRD, integer);
    wr32le(PL011_0_BASE + PL011_FBRD, fractional);
    wr32le(PL011_0_BASE + PL011_LCRH, PL011_LCRH_WLEN8 | PL011_LCRH_FEN);
    wr32le(PL011_0_BASE + PL011_CR,
           PL011_CR_UARTEN | PL011_CR_TXE | PL011_CR_RXE |
           PL011_CR_RTSEN | PL011_CR_CTSEN);
    dsb();

    uint32_t fr = rd32le(PL011_0_BASE + PL011_FR);
    if (diag_page) {
        diag_page->uart_ibrd = integer;
        diag_page->uart_fbrd = fractional;
        diag_page->uart_fr_active = fr;
    }
    kprintf("[BT-HCI] UART 115200 8N1 RTS/CTS IBRD=%u FBRD=%u FR=%08x CTS=%u\n",
            integer, fractional, fr, !!(fr & PL011_FR_CTS));

    /* CTS not asserted: don't queue bytes against an unpowered controller. */
    uint64_t cts_deadline = counter_deadline_ms(150);
    while (!(fr & PL011_FR_CTS) && before_deadline(cts_deadline))
        fr = rd32le(PL011_0_BASE + PL011_FR);
    if (!(fr & PL011_FR_CTS)) {
        if (diag_page) diag_page->stop_reason = BTDIAG_STOP_NO_CTS;
        kprintf("[BT-HCI] NO CTS: controller may be off/unclocked; skipping HCI\n");
        restore_uart(&old);
        return;
    }

    if (diag_page) diag_page->cts_seen = 1;
    unsigned drained = drain_rx();
    if (diag_page) diag_page->rx_discarded = drained;
    if (drained)
        kprintf("[BT-HCI] Discarded %u stale UART bytes\n", drained);

    uint8_t result[32];
    unsigned length = sizeof(result);
    int rc = hci_command(HCI_RESET_OPCODE, result, &length);
    if (diag_page) {
        diag_page->reset_rc = rc;
        diag_page->reset_len = length;
        diag_page->reset_status = (rc == 0 && length) ? result[0] : 0xffu;
    }
    if (rc || length < 1 || result[0]) {
        if (diag_page) diag_page->stop_reason = BTDIAG_STOP_RESET_FAILED;
        kprintf("[BT-HCI] HCI_Reset FAILED rc=%d len=%u status=%02x (no firmware load attempted)\n",
                rc, length, rc == 0 && length ? result[0] : 0xffu);
        restore_uart(&old);
        return;
    }
    kprintf("[BT-HCI] HCI_Reset OK\n");

    length = sizeof(result);
    rc = hci_command(HCI_VERSION_OPCODE, result, &length);
    if (diag_page) {
        diag_page->version_rc = rc;
        diag_page->version_len = length;
        diag_page->version_status = (rc == 0 && length) ? result[0] : 0xffu;
    }
    if (rc || length < 9 || result[0]) {
        if (diag_page) diag_page->stop_reason = BTDIAG_STOP_VERSION_FAILED;
        kprintf("[BT-HCI] Read_Local_Version FAILED rc=%d len=%u status=%02x\n",
                rc, length, rc == 0 && length ? result[0] : 0xffu);
    } else {
        uint16_t rev = (uint16_t)result[2] | ((uint16_t)result[3] << 8);
        uint16_t maker = (uint16_t)result[5] | ((uint16_t)result[6] << 8);
        uint16_t sub = (uint16_t)result[7] | ((uint16_t)result[8] << 8);
        if (diag_page) {
            diag_page->hci_version = result[1];
            diag_page->hci_revision = rev;
            diag_page->lmp_version = result[4];
            diag_page->manufacturer = maker;
            diag_page->lmp_subversion = sub;
            diag_page->stop_reason = BTDIAG_STOP_OK;
        }
        kprintf("[BT-HCI] SUCCESS HCI=%u rev=%04x LMP=%u manufacturer=%u subversion=%04x\n",
                result[1], rev, result[4], maker, sub);
    }
    if (diag_page && diag_page->stop_reason == BTDIAG_STOP_OK && probe_mode >= 3) {
#ifdef EMU68_BT_HCI_POC3
        patchram_run();
#else
        diag_page->stop_reason = BTDIAG_STOP_FW_NOT_BUILT;
#endif
    }
#ifdef EMU68_BT_HCI_POC4
    if ((probe_mode == 4 || probe_mode == 5 || probe_mode == 6 || probe_mode == 7) && diag_page &&
        diag_page->stop_reason == BTDIAG_STOP_FW_SUCCESS) {
#ifdef EMU68_BT_HCI_POC5
        if ((probe_mode == 5 || probe_mode == 6 || probe_mode == 7) &&
            (configured_peer_bad ||
             ((probe_mode != 7) && !configured_peer_valid) ||
             configured_bd_addr_bad || !configured_bd_addr_valid ||
             (configured_bond_bad && probe_mode >= 6) ||
             (configured_bond_valid && !configured_peer_valid && probe_mode == 7))) {
            diag_page->stop_reason = configured_bond_bad ||
                (configured_bond_valid && !configured_peer_valid) ?
                BTDIAG_STOP_BAD_BOND :
                (configured_peer_bad || ((probe_mode != 7) && !configured_peer_valid)) ?
                BTDIAG_STOP_PAIR_BAD_PEER : BTDIAG_STOP_PAIR_MISSING_ADDR;
        } else
#endif
        {
            poc4_run(probe_mode == 4);
            if (probe_mode == 7 && !configured_peer_valid &&
                diag_page->stop_reason == BTDIAG_STOP_FW_SUCCESS &&
                diag_page->uart_owned)
                poc8_scan_wait();
#ifdef EMU68_BT_HCI_POC5
            if (probe_mode == 5 &&
                diag_page->stop_reason == BTDIAG_STOP_FW_SUCCESS)
                p5_run();
#ifdef EMU68_BT_HCI_POC6
            if ((probe_mode == 6 || probe_mode == 7) &&
                diag_page->stop_reason == BTDIAG_STOP_FW_SUCCESS){
                if(diag_page->recover_stage==2u)diag_page->recover_stage=3u;
                if(bt_poc6_run(diag_page,configured_peer_addr,probe_mode == 7u,
                    configured_bond_key, configured_bond_type, configured_bond_valid,
                    control_page)) bt_manual_recover_pending=1u;
            }
#endif
#endif
        }
        /* UART ownership belongs to CPU3, including on failures AFTER
         * the Broadcom rate switch. Restoring only host UART would leave
         * controller and host at different baud rates. */
        if (diag_page->uart_owned) {
            kprintf("[BT-HCI] POC4 keeps UART on CPU3; result=%u devices=%u\n",
                    diag_page->stop_reason, diag_page->scan_count);
            return;
        }
    }
#endif
    restore_uart(&old);
    kprintf("[BT-HCI] Diagnostic complete; UART and GPIO30-33 restored\n");
}

void bt_hci_probe_run(void)
{
    if (diag_page) {
        diag_page->cpu3_seen = 1u;
        diag_page->state = BTDIAG_STATE_RUNNING;
        dsb();
    }
    if (!probe_mode) {
        diag_done();
        return;
    }
    /* POC11-A feasibility experiment: only the dedicated Bluetooth CPU3
     * waits. CPU0/CPU1 and AmigaOS keep booting, so WiFiPi can bring the
     * WLAN online BEFORE any Bluetooth GPIO/UART/HCI initialization.
     * Removing "pause" restores the original boot path (no binary rollback).
     */
    if (probe_mode == 7u && bt_boot_pause_60s) {
        kprintf("[BT-HCI] POC11-A: delaying CPU3 Bluetooth bootstrap for 60s\n");
        uint64_t until = counter_deadline_ms(60000u);
        while (before_deadline(until)) {
            __asm__ volatile("yield");
        }
        kprintf("[BT-HCI] POC11-A: continuing normal Bluetooth bootstrap\n");
    }
    uint32_t fsel3 = rd32le(GPIO_GPFSEL3);
    uint32_t fsel4 = rd32le(GPIO_GPFSEL4);
    uint32_t gp2ctl = rd32le(CM_GP2CTL);
    uint32_t gp2div = rd32le(CM_GP2DIV);
    if (diag_page) {
        diag_page->fsel3 = fsel3;
        diag_page->fsel4 = fsel4;
        diag_page->gp2ctl = gp2ctl;
        diag_page->gp2div = gp2div;
        diag_page->uart_cr = rd32le(PL011_0_BASE + PL011_CR);
        diag_page->uart_fr = rd32le(PL011_0_BASE + PL011_FR);
    }
    kprintf("[BT-HCI] CPU3 GPIO30-33 FSEL=%u,%u,%u,%u GPIO43=%u\n",
            gpio_function(fsel3, 30), gpio_function(fsel3, 31),
            gpio_function(fsel3, 32), gpio_function(fsel3, 33),
            gpio_function(fsel4, 43));
    kprintf("[BT-HCI] GPCLK2 CTL=%08x DIV=%08x PL011 CR=%08x FR=%08x\n",
            gp2ctl, gp2div,
            rd32le(PL011_0_BASE + PL011_CR),
            rd32le(PL011_0_BASE + PL011_FR));
    if (probe_mode >= 2) {
        probe_active(fsel3, fsel4, gp2ctl);
        /* Only an explicit request from the POC11-B control page can cause
         * this CPU3 loop. Pause is a boot-time-only option, not reapplied. */
        /* No new CPU3 idle loop is introduced on the validated cold-boot
         * path; the supervisor exists only after explicit --recover. */
        if(bt_manual_recover_pending && probe_mode==7u && control_page)
        while(probe_mode==7u && control_page){
            if(bt_manual_recover_pending){
                bt_manual_recover_pending=0u;
                diag_page->recover_attempts++;
                diag_page->recover_stage=2u;
                diag_page->recover_last_error=0u;
                /* Snapshot/stop flags for NEW bootstrap. Do not change
                 * BTCTRL request_seq: the m68k tool is waiting on it. */
                diag_page->fw_records_sent=0;
                diag_page->fw_command_rc=-99;
                diag_page->fw_command_status=0xff;
                diag_page->uart_owned=0;
                diag_page->baud_verified=0;
                diag_page->a2dp_transport_errors=0;
                diag_page->a2dp_packets=0;
                diag_page->a2dp_sbc_frames=0;
                diag_page->a2dp_stream_open=0;
                diag_page->a2dp_stream_started=0;
                diag_page->bond_db_readback=0;
                diag_page->bond_local_addr_match=0;
                diag_page->stop_reason=BTDIAG_STOP_NONE;
                /* Return from BTstack was after full local teardown;
                 * invoke the ORIGINAL POC3-P4 firmware+baud sequence. */
                probe_active(rd32le(GPIO_GPFSEL3),rd32le(GPIO_GPFSEL4),
                             rd32le(CM_GP2CTL));
                continue;
            }
            /* Bootstrap failed before BTstack reached HCI WORKING: report
             * failure but stay on CPU3 for a later explicit retry. */
            if(diag_page->recover_stage==2u || diag_page->recover_stage==3u){
                diag_page->recover_stage=5u;
                diag_page->recover_failures++;
                diag_page->recover_last_error=diag_page->stop_reason;
                control_page->result=BTCTRL_FAILED;
                dsb();
                control_page->completed_seq=control_page->request_seq;
                dsb();
            }
            uint32_t seq=control_page->request_seq;
            if(seq!=control_page->completed_seq){
                if(control_page->command==BTCTRL_RECOVER){
                    bt_manual_recover_pending=1u;
                }else{
                    control_page->result=BTCTRL_BAD_MODE;
                    dsb();control_page->completed_seq=seq;dsb();
                }
            }
            __asm__ volatile("yield");
        }
    } else
        kprintf("[BT-HCI] Read-only diagnostic complete; nothing changed\n");
    diag_done();
}
