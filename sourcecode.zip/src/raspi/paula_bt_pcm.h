/* POC7 Paula -> BTstack PCM ring, ARM-only interface. */
#ifndef EMU68_PAULA_BT_PCM_H
#define EMU68_PAULA_BT_PCM_H
#include <stdint.h>
#include "bt_hci_shared.h"
void emu68_paula_bt_init(void);
void emu68_paula_bt_cpu1_worker(void);
void emu68_paula_bt_read_pcm(int16_t *out,unsigned frames);
void emu68_paula_bt_snapshot(volatile struct bt_hci_diag_shared *diag);
#endif
