# AirPaula POC11-B FIX1 — project-only source overlay

Target Emu68 baseline: `9b4379a5c5dbf7f12f5e10cfe81a96b872e2426f`.

This archive contains the **AirPaula integration files** that differ from the clean Emu68 base, plus the **adapted Paula emulator sources and required MIT license**. Original Emu68-relative paths are preserved, ready to overlay on that exact revision.

Unlike the full hardware-validated milestone, this archive deliberately **does not include**:

- `third_party/btstack/` (BlueKitchen third-party library; must be supplied separately);
- `firmware/BCM4345C0.hcd` (Broadcom/Cypress firmware; must be supplied separately);
- the stock Emu68 files and submodules;
- prebuilt kernel or AmigaOS executables.

The source code is the POC11-B FIX1 + MiamiDX Events hardware-validated source set, but this **lightweight archive alone is not self-contained for building**. Use the compatible BTstack snapshot and Broadcom PatchRAM file from the complete milestone, or independently obtain and verify matching dependencies. No dependency versions are inferred here.

Apply from the root of a clean Emu68 checkout at the specified base commit:

```
unzip -o AirPaula-POC11B-FIX1-PROJECT-ONLY-OVERLAY.zip
```

This archive contains no WiFiPi.device modifications. The established configuration uses `BTDiag --recover` with MiamiDX Events after WiFiPi is brought online. `BTDiag --scan` and `BTDiag --key` are preserved.

See `AIRPAULA-CREDITS.md` for authors, projects, links and license obligations.
