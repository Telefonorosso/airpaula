/* BTDiag for AmigaOS 3.x / Emu68-Paula-BT HCI POC9 (warm reboot recovery).
 * SPDX-License-Identifier: MPL-2.0
 * Compile: m68k-amigaos-gcc -m68020 -O2 -Wall -Wextra -o BTDiag BTDiag.c
 * WARNING: Run ONLY with Emu68-Paula-BT POC8 kernel, which maps these apertures.
 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <proto/dos.h>
#include "bt_hci_shared.h"

static const char *state_name(uint32_t s)
{
    switch (s) {
        case BTDIAG_STATE_WAIT: return "CPU3 not started";
        case BTDIAG_STATE_RUNNING: return "probe running";
        case BTDIAG_STATE_DONE: return "complete";
        default: return "unknown";
    }
}

static const char *reason_name(uint32_t reason)
{
    switch (reason) {
        case BTDIAG_STOP_NONE: return "not attempted";
        case BTDIAG_STOP_NO_CLOCK: return "UART clock unavailable";
        case BTDIAG_STOP_BAD_GPCLK2: return "GPCLK2 disabled/mux mismatch";
        case BTDIAG_STOP_BAD_DIVISOR: return "bad UART baud divisor";
        case BTDIAG_STOP_NO_CTS: return "no CTS from Bluetooth chip";
        case BTDIAG_STOP_RESET_FAILED: return "HCI_Reset failed";
        case BTDIAG_STOP_VERSION_FAILED: return "HCI_Read_Local_Version failed";
        case BTDIAG_STOP_OK: return "HCI success";
        case BTDIAG_STOP_FW_NOT_BUILT: return "PatchRAM not compiled";
        case BTDIAG_STOP_FW_UNEXPECTED_CHIP: return "controller ID mismatch - NOT flashed";
        case BTDIAG_STOP_FW_MINIDRV_FAILED: return "Download MiniDriver failed";
        case BTDIAG_STOP_FW_RECORD_FAILED: return "PatchRAM record failed";
        case BTDIAG_STOP_FW_CORRUPT: return "Invalid firmware structure";
        case BTDIAG_STOP_FW_POSTRESET_FAILED: return "post PatchRAM HCI Reset failed";
        case BTDIAG_STOP_FW_POSTVERSION_FAILED: return "post PatchRAM version read failed";
        case BTDIAG_STOP_FW_SUCCESS: return "PatchRAM sequence completed";
        case BTDIAG_STOP_FW_BUDGET: return "PatchRAM global deadline";
        case BTDIAG_STOP_BAD_ADDRESS: return "invalid bt_bdaddr parameter";
        case BTDIAG_STOP_SET_ADDRESS_FAILED: return "local BD_ADDR write/readback failed";
        case BTDIAG_STOP_BAUD_COMMAND_FAILED: return "controller refused baud switch";
        case BTDIAG_STOP_BAUD_HOST_FAILED: return "host UART baud switch failed";
        case BTDIAG_STOP_BAUD_VERIFY_FAILED: return "HCI at 921600 baud failed";
        case BTDIAG_STOP_INQUIRY_FAILED: return "Bluetooth Classic inquiry failed";
        case BTDIAG_STOP_INQUIRY_OK: return "Bluetooth Classic inquiry complete";
        case BTDIAG_STOP_PAIR_MISSING_ADDR: return "No valid local BD_ADDR (DT or bt_bdaddr=)";
        case BTDIAG_STOP_PAIR_BAD_PEER: return "Valid bt_peer required for pairing";
        case BTDIAG_STOP_PAIR_SETUP_FAILED: return "SSP/event mask/baud setup failed";
        case BTDIAG_STOP_PAIR_CREATE_FAILED: return "Create Connection command failed";
        case BTDIAG_STOP_PAIR_CONNECTION_FAILED: return "ACL connection failed or closed";
        case BTDIAG_STOP_PAIR_AUTH_FAILED: return "SSP authentication failed";
        case BTDIAG_STOP_PAIR_ENCRYPT_FAILED: return "link encryption failed";
        case BTDIAG_STOP_PAIR_SUCCESS: return "ACL, SSP and encryption successful";
        case BTDIAG_STOP_PAIR_TIMEOUT: return "45s pairing deadline reached";
        case BTDIAG_STOP_PAIR_EVENT_FAILED: return "HCI response/transport error";
        case BTDIAG_STOP_PAIR_LEGACY_UNSUPPORTED: return "Legacy PIN pairing unsupported";
        case BTDIAG_STOP_PAIR_NOT_BUILT: return "POC5 not compiled";
        case BTDIAG_STOP_A2DP_INIT_FAILED: return "BTstack A2DP initialization failed";
        case BTDIAG_STOP_A2DP_CONNECT_FAILED: return "A2DP connection failed";
        case BTDIAG_STOP_A2DP_TIMEOUT: return "A2DP test timed out";
        case BTDIAG_STOP_A2DP_TONE_COMPLETE: return "SBC tone transmitted (audibility to check)";
        case BTDIAG_STOP_A2DP_STREAM_FAILED: return "A2DP stream failed or closed";
        case BTDIAG_STOP_A2DP_PAULA_LIVE: return "Paula A2DP live stream active";
        case BTDIAG_STOP_BAD_BOND: return "invalid bt_bond=TYPE:KEY configuration";
        case BTDIAG_STOP_A2DP_RECONNECTING: return "A2DP reconnecting autonomously";
        default: return "unknown";
    }
}

/* Commands use a SECOND, explicitly writable/non-cached page. Never write
 * the diagnostic page: it deliberately remains read-only to AmigaOS.
 * A monotonic sequence is committed last, followed by a DOS Delay() poll.
 */
static int request_poc8_command(uint32_t opcode, int key_mode)
{
    const volatile struct bt_hci_diag_shared *diag =
        (const volatile struct bt_hci_diag_shared *)(uintptr_t)BTDIAG_ADDRESS;
    volatile struct bt_hci_control_shared *control =
        (volatile struct bt_hci_control_shared *)(uintptr_t)BTCTRL_ADDRESS;
    unsigned i;
    uint32_t seq;
    if (diag->magic != BTDIAG_MAGIC || diag->version != BTDIAG_VERSION ||
        diag->size != sizeof(*diag)) {
        puts("POC8 kernel and BTDiag version mismatch");
        return 20;
    }
    if (control->magic != BTCTRL_MAGIC ||
        control->version != BTCTRL_VERSION ||
        control->size != sizeof(*control)) {
        puts("POC8 command page unavailable");
        return 20;
    }
    if (diag->mode != 7 || (key_mode && !diag->pair_requested) ||
        (!key_mode && diag->pair_requested)) {
        puts(key_mode ? "--key requires paula_bt with bt_peer=" :
                        "--scan requires paula_bt WITHOUT bt_peer=");
        return 10;
    }
    if (diag->state != BTDIAG_STATE_RUNNING) {
        puts("CPU3 is not running; check BTDiag and controller status");
        return 10;
    }
    if (control->request_seq != control->completed_seq) {
        puts("Previous command still in progress");
        return 10;
    }
    /* Overwrite stale key data, including after a previous export. */
    for (i=0; i<16; i++) control->link_key[i]=0;
    control->key_type=0;
    control->result=0;
    control->command=opcode;
    seq=control->request_seq + 1u;
    if (!seq) seq=1;
    control->request_seq=seq;
    printf("%s...\n",key_mode?"Requesting bond key":"Scanning Bluetooth Classic devices");
    /* Scan HCI inquiry takes ~10.24 s plus command setup. */
    for (i=0; i<(key_mode?100u:450u); ++i) {
        if (control->completed_seq==seq) break;
        Delay(2); /* PAL 50 Hz ticks; bounded, no CPU busy loop. */
    }
    if (control->completed_seq != seq) {
        puts("Timeout; run BTDiag to inspect CPU3 state");
        return 10;
    }
    if (control->result != BTCTRL_OK) {
        if (control->result==BTCTRL_NO_KEY)
            puts("No Link Key yet. Pair first, then run BTDiag --key.");
        else
            printf("Command failed (code %lu); run BTDiag for details.\n",
                   (unsigned long)control->result);
        return 5;
    }
    if (key_mode) {
        char hexkey[33];
        static const char h[]="0123456789ABCDEF";
        uint32_t type=control->key_type;
        uint8_t mac[6];
        for (i=0;i<16;i++) {
            uint8_t b=control->link_key[i];
            hexkey[2*i]=h[b>>4];
            hexkey[2*i+1]=h[b&15u];
            control->link_key[i]=0;  /* Clean shared secret after reading. */
        }
        hexkey[32]=0;
        for (i=0;i<6;i++) mac[i]=control->peer[i];
        if (type!=4 && type!=5 && type!=7 && type!=8) {
            puts("Unsupported key type; refusing to generate bt_bond");
            memset(hexkey,0,sizeof(hexkey));
            return 5;
        }
        puts("Add the following line to config.txt (secret: do not publish):");
        printf("dtparam=args=paula_bt bt_peer=%02X:%02X:%02X:%02X:%02X:%02X bt_bond=%lu:%s\n",
               mac[0],mac[1],mac[2],mac[3],mac[4],mac[5],
               (unsigned long)type,hexkey);
        memset(hexkey,0,sizeof(hexkey));
    } else {
        uint32_t count=diag->scan_count;
        printf("Found %lu device(s):\n",(unsigned long)count);
        if (count>BTDIAG_MAX_DEVICES) count=BTDIAG_MAX_DEVICES;
        for(i=0;i<count;i++) {
            const volatile struct bt_hci_scan_device *d=&diag->devices[i];
            printf("%lu. %02X:%02X:%02X:%02X:%02X:%02X",
                   (unsigned long)(i+1),d->address[0],d->address[1],
                   d->address[2],d->address[3],d->address[4],d->address[5]);
            if(d->flags&1u) printf(" RSSI=%ld",(long)d->rssi);
            if(d->flags&2u) printf(" %s",(const char *)d->name);
            putchar('\n');
        }
        puts("Configure bt_peer=MAC in config.txt, then cold-boot.");
    }
    return 0;
}

/* POC11-B manual BT-only controller recovery.  The kernel is still
 * responsible for all HCI/BTstack work; this tool only posts a command.
 * POC8 --scan/--key handler above deliberately remains untouched. */
static int request_manual_recover(void)
{
    const volatile struct bt_hci_diag_shared *diag =
        (const volatile struct bt_hci_diag_shared *)(uintptr_t)BTDIAG_ADDRESS;
    volatile struct bt_hci_control_shared *ctl =
        (volatile struct bt_hci_control_shared *)(uintptr_t)BTCTRL_ADDRESS;
    uint32_t seq;
    unsigned i;
    if(diag->magic!=BTDIAG_MAGIC || diag->version!=BTDIAG_VERSION ||
       diag->size!=sizeof(*diag) || ctl->magic!=BTCTRL_MAGIC ||
       ctl->version!=BTCTRL_VERSION || ctl->size!=sizeof(*ctl)){
        puts("POC11-B kernel / BTDiag mismatch");return 20;
    }
    if(diag->mode!=7u || !diag->pair_requested ||
       !diag->a2dp_stack_started || diag->state!=BTDIAG_STATE_RUNNING){
        puts("--recover requires active paula_bt with bt_peer=");return 10;
    }
    if(ctl->request_seq!=ctl->completed_seq){
        puts("Another BTDiag command is pending");return 10;
    }
    /* No key material crosses this command. */
    ctl->result=0;
    ctl->command=BTCTRL_RECOVER;
    seq=ctl->request_seq+1u;
    if(!seq)seq=1u;
    ctl->request_seq=seq;
    puts("Requesting Bluetooth-only rebootstrap; WiFiPi remains untouched...");
    /* PatchRAM can take up to 60 s; allow 100-120 seconds PAL/NTSC. */
    for(i=0;i<3000u;i++){
        if(ctl->completed_seq==seq) break;
        Delay(2);
    }
    if(ctl->completed_seq!=seq){
        puts("Recovery timeout; inspect BTDiag diagnostics");return 10;
    }
    if(ctl->result!=BTCTRL_OK){
        printf("Recovery failed, code %lu. Inspect BTDiag.\n",
               (unsigned long)ctl->result);return 5;
    }
    puts("HCI WORKING after rebootstrap. A2DP will reconnect via POC9.");
    puts("Use BTDiag to confirm stream_open=1, started=1 and audio.");
    return 0;
}

/* AmigaOS startup variants do not always deliver Unix-like argc/argv.
 * In particular, some CRTs expose the complete DOS argument line instead.
 * GetArgStr() is the native DOS V36+ accessor; trim the CLI newline explicitly.
 * Do not accept extra tokens, to avoid silently executing a wrong command.
 */
static int bt_cli_space(unsigned char ch)
{
    return ch==' ' || ch=='\t' || ch=='\r' || ch=='\n';
}

static int bt_cli_equals(const char *value, const char *expected)
{
    unsigned char a, b;
    while (*value && *expected) {
        a=(unsigned char)*value++;
        b=(unsigned char)*expected++;
        if (a>='A' && a<='Z') a=(unsigned char)(a-'A'+'a');
        if (b>='A' && b<='Z') b=(unsigned char)(b-'A'+'a');
        if (a!=b) return 0;
    }
    return !*value && !*expected;
}

/* 0=diagnostic, 1=scan, 2=key, 3=recover, -1=invalid arguments. */
static int bt_cli_decode(const char *argline)
{
    char word[32];
    unsigned n=0;
    if (!argline) return 0;
    while (bt_cli_space((unsigned char)*argline)) ++argline;
    if (!*argline) return 0;
    while (*argline && !bt_cli_space((unsigned char)*argline)) {
        if (n>=sizeof(word)-1) return -1;
        word[n++]=*argline++;
    }
    word[n]=0;
    while (bt_cli_space((unsigned char)*argline)) ++argline;
    if (*argline) return -1;   /* No unrecognised second argument. */
    if (bt_cli_equals(word,"--scan") || bt_cli_equals(word,"-scan") ||
        bt_cli_equals(word,"scan")) return 1;
    if (bt_cli_equals(word,"--key") || bt_cli_equals(word,"-key") ||
        bt_cli_equals(word,"key")) return 2;
    if (bt_cli_equals(word,"--recover") || bt_cli_equals(word,"-recover") ||
        bt_cli_equals(word,"recover")) return 3;
    return -1;
}

static int bt_cli_command(int argc, char **argv)
{
    int cmd;
    const char *raw;
    /* Ordinary Amiga GCC startup path, with trailing whitespace tolerated. */
    if (argc > 2) return -1;
    if (argc == 2 && argv && argv[1]) {
        cmd=bt_cli_decode(argv[1]);
        if (cmd > 0) return cmd;
    }
    /* Native AmigaDOS fallback (also works when CRT reports argc == 1).
     * The DOS CLI argument string contains arguments only, not the tool name.
     */
    raw=(const char *)GetArgStr();
    cmd=bt_cli_decode(raw);
    if (cmd > 0) return cmd;
    if (argc == 2) return -1;
    return cmd;
}

int main(int argc, char **argv)
{
    const volatile struct bt_hci_diag_shared *p =
        (const volatile struct bt_hci_diag_shared *)(uintptr_t)BTDIAG_ADDRESS;
    struct bt_hci_diag_shared x;
    uint32_t seq1, seq2;
    {
        int command=bt_cli_command(argc,argv);
        if (command==1) return request_poc8_command(BTCTRL_SCAN,0);
        if (command==2) return request_poc8_command(BTCTRL_KEY,1);
        if (command==3) return request_manual_recover();
        if (command<0) {
            puts("Usage: BTDiag [--scan | --key | --recover]");
            return 10;
        }
    }
    puts("Emu68 Paula-BT HCI POC11-B -- CPU3 diagnostic");
    puts("WARNING: requires POC8 kernel (NOT stock Emu68)");

    /* Fixed POC address. Reading it with a non-POC4 kernel can Bus Error. */
    if (p->magic != BTDIAG_MAGIC || p->version != BTDIAG_VERSION ||
        p->size != sizeof(x)) {
        puts("Invalid BT diagnostic page (wrong kernel/version)");
        return 20;
    }

    /* One-shot producer: state DONE is stored only after all fields.
     * Avoid displaying any partial UART/HCI measurements as valid. */
    seq1 = p->state;
    if (seq1 != BTDIAG_STATE_DONE && !(p->mode == 7u && seq1 == BTDIAG_STATE_RUNNING)) {
        printf("State: %s (%lu), mode: %lu, CPU3 seen: %lu\n",
               state_name(seq1), (unsigned long)seq1,
               (unsigned long)p->mode, (unsigned long)p->cpu3_seen);
        return 5;
    }
    {
        const volatile uint32_t *s = (const volatile uint32_t *)p;
        uint32_t *d = (uint32_t *)&x;
        unsigned i;
        for (i = 0; i < sizeof(x) / sizeof(uint32_t); i++)
            d[i] = s[i];
    }
    seq2 = p->state;
    if ((seq2 != BTDIAG_STATE_DONE && !(x.mode == 7u && seq2 == BTDIAG_STATE_RUNNING)) || x.magic != BTDIAG_MAGIC) {
        puts("Diagnostic changed while reading; retry");
        return 10;
    }

    printf("Mode: %s; CPU3: %s\n",
           x.mode == 7 ? "Paula A2DP live" : x.mode == 6 ? "A2DP SBC tone" : x.mode == 5 ? "ACL/SSP pairing" :
           x.mode == 4 ? "Classic inquiry" : x.mode == 3 ? "PatchRAM" : x.mode == 2 ? "active probe" : x.mode == 1 ? "read-only" : "disabled",
           x.cpu3_seen ? "executed" : "not executed");
    printf("GPIO30-33 FSEL: %lu %lu %lu %lu\n",
           (unsigned long)(x.fsel3 & 7u),
           (unsigned long)((x.fsel3 >> 3) & 7u),
           (unsigned long)((x.fsel3 >> 6) & 7u),
           (unsigned long)((x.fsel3 >> 9) & 7u));
    printf("GPIO43 FSEL: %lu\n", (unsigned long)((x.fsel4 >> 9) & 7u));
    printf("GPCLK2: CTL=%08lx DIV=%08lx\n",
           (unsigned long)x.gp2ctl, (unsigned long)x.gp2div);
    printf("PL011: CR=%08lx FR=%08lx\n",
           (unsigned long)x.uart_cr, (unsigned long)x.uart_fr);

    if (x.mode < 2) {
        puts(x.mode == 1 ? "Read-only diagnostic: HCI commands not sent" :
             "Diagnostic disabled in Emu68 boot arguments");
        if (x.mode == 7u) {
        printf("Paula PCM: produced=%lu consumed=%lu ring=%lu underruns=%lu overruns=%lu\n",
            (unsigned long)x.paula_pcm_produced, (unsigned long)x.paula_pcm_consumed,
            (unsigned long)x.paula_ring_fill, (unsigned long)x.paula_underruns,
            (unsigned long)x.paula_overruns);
        printf("Paula source: nonzero=%lu peak=%lu mirror_drops=%lu cache_misses=%lu\n",
            (unsigned long)x.paula_nonzero_frames, (unsigned long)x.paula_pcm_peak,
            (unsigned long)x.paula_capture_drops, (unsigned long)x.paula_cache_misses);
        puts("Session is live; run BTDiag again to observe changing counters.");
    }
    return 0;
    }
    printf("PL011 clock: %lu Hz; IBRD=%lu FBRD=%lu; active FR=%08lx\n",
           (unsigned long)x.uart_clock_hz,
           (unsigned long)x.uart_ibrd, (unsigned long)x.uart_fbrd,
           (unsigned long)x.uart_fr_active);
    printf("CTS: %s, drained RX: %lu, UART restored: %s\n",
           x.cts_seen ? "yes" : "no",
           (unsigned long)x.rx_discarded,
           x.uart_restored ? "yes" : "no/not touched");
    printf("Result: %s (%lu)\n", reason_name(x.stop_reason),
           (unsigned long)x.stop_reason);
    if (x.reset_rc != -99)
        printf("HCI Reset: rc=%ld len=%lu status=%02lx\n",
               (long)x.reset_rc, (unsigned long)x.reset_len,
               (unsigned long)x.reset_status);
    if (x.version_rc != -99)
        printf("HCI Version: rc=%ld len=%lu status=%02lx\n",
               (long)x.version_rc, (unsigned long)x.version_len,
               (unsigned long)x.version_status);
    if ((x.stop_reason == BTDIAG_STOP_OK || x.mode == 3) &&
        x.version_rc == 0 && x.version_status == 0) {
        printf("HCI=%lu rev=%04lx LMP=%lu manufacturer=%lu subversion=%04lx\n",
               (unsigned long)x.hci_version,
               (unsigned long)x.hci_revision,
               (unsigned long)x.lmp_version,
               (unsigned long)x.manufacturer,
               (unsigned long)x.lmp_subversion);
    }
    if (x.mode >= 3) {
        printf("PatchRAM: %lu bytes, %lu/%lu records completed\n",
               (unsigned long)x.fw_image_bytes,
               (unsigned long)x.fw_records_sent,
               (unsigned long)x.fw_records_total);
        printf("Last record: offset=%lu opcode=%04lx rc=%ld status=%02lx\n",
               (unsigned long)x.fw_failed_offset,
               (unsigned long)x.fw_failed_opcode,
               (long)x.fw_command_rc,
               (unsigned long)x.fw_command_status);
        if (x.fw_records_sent == x.fw_records_total && x.post_hci_version != 0) {
            printf("After PatchRAM: HCI=%lu rev=%04lx LMP=%lu manufacturer=%lu subversion=%04lx\n",
                   (unsigned long)x.post_hci_version,
                   (unsigned long)x.post_hci_revision,
                   (unsigned long)x.post_lmp_version,
                   (unsigned long)x.post_manufacturer,
                   (unsigned long)x.post_lmp_subversion);
            if (x.bd_addr_valid)
                printf("Bluetooth Address: %02lx:%02lx:%02lx:%02lx:%02lx:%02lx\n",
                       (unsigned long)((x.bd_addr_hi >> 8) & 255u),
                       (unsigned long)(x.bd_addr_hi & 255u),
                       (unsigned long)((x.bd_addr_lo >> 24) & 255u),
                       (unsigned long)((x.bd_addr_lo >> 16) & 255u),
                       (unsigned long)((x.bd_addr_lo >> 8) & 255u),
                       (unsigned long)(x.bd_addr_lo & 255u));
        }
    }
    if (x.mode == 4 || x.mode == 5 || x.mode == 6 || x.mode == 7) {
        unsigned i;
        printf("PL011: %lu baud, verified=%s, CPU3 owns UART=%s\n",
               (unsigned long)x.scan_uart_baud,
               x.baud_verified ? "yes" : "no",
               x.uart_owned ? "yes" : "no");
        printf("Local address: %s\n",
               x.address_config_state == 2 ?
                    (x.bd_addr_source == 2 ? "native Device Tree address applied" :
                     "manual override applied") :
               x.address_config_state == 3 ? "invalid option" :
               x.address_config_state == 1 ? "requested, not yet applied" :
               "unavailable (stock Broadcom address unsafe for pairing)");
        if (x.mode == 4 || (x.mode == 7 && !x.pair_requested)) {
        printf("Classic inquiry: mode=%lu complete=%s rc=%ld, %lu device(s)\n",
               (unsigned long)x.scan_mode,
               x.scan_complete ? "yes" : "no", (long)x.scan_rc,
               (unsigned long)x.scan_count);
        for (i = 0; i < x.scan_count && i < BTDIAG_MAX_DEVICES; ++i) {
            const struct bt_hci_scan_device *d = &x.devices[i];
            printf("%lu. %02lx:%02lx:%02lx:%02lx:%02lx:%02lx CoD=%06lx",
                (unsigned long)(i + 1),
                (unsigned long)d->address[0], (unsigned long)d->address[1],
                (unsigned long)d->address[2], (unsigned long)d->address[3],
                (unsigned long)d->address[4], (unsigned long)d->address[5],
                (unsigned long)d->class_of_device);
            if (d->flags & 1u) printf(" RSSI=%ld", (long)d->rssi);
            if (d->flags & 2u) printf(" Name='%s'", d->name);
            putchar('\n');
        }
        } else if (x.mode == 5) {
            printf("Target: %02lx:%02lx:%02lx:%02lx:%02lx:%02lx\n",
                   (unsigned long)x.pair_peer[0], (unsigned long)x.pair_peer[1],
                   (unsigned long)x.pair_peer[2], (unsigned long)x.pair_peer[3],
                   (unsigned long)x.pair_peer[4], (unsigned long)x.pair_peer[5]);
            printf("ACL connected=%s handle=%04lx status=%02lx\n",
                   x.pair_acl_connected ? "yes" : "no",
                   (unsigned long)x.pair_handle,
                   (unsigned long)x.pair_connection_status);
            printf("SSP completed=%s authenticated=%s encrypted=%s\n",
                   x.pair_ssp_complete ? "yes" : "no",
                   x.pair_authenticated ? "yes" : "no",
                   x.pair_encrypted ? "yes" : "no");
            printf("Link key generated=%s (RAM only, never printed)\n",
                   x.pair_link_key_seen ? "yes" : "no");
            printf("IO cap requests=%lu confirmation requests=%lu legacy PIN requests=%lu\n",
                   (unsigned long)x.pair_io_capability_requests,
                   (unsigned long)x.pair_confirmation_requests,
                   (unsigned long)x.pair_legacy_pin_requests);
            printf("Authentication status=%02lx encryption status=%02lx\n",
                   (unsigned long)x.pair_auth_status,
                   (unsigned long)x.pair_encryption_status);
            printf("Last HCI event=%02lx opcode=%04lx status=%02lx\n",
                   (unsigned long)x.pair_last_event,
                   (unsigned long)x.pair_last_opcode,
                   (unsigned long)x.pair_last_status);
            printf("Elapsed=%lu ms disconnected=%s\n",
                   (unsigned long)x.pair_elapsed_ms,
                   x.pair_disconnected ? "yes" : "no");
        }
    }
    if (x.mode == 7) {
        printf("Bond configured=%s loaded into BTstack=%s DB readback=%s\n",
            x.bond_configured ? "yes" : "no", x.bond_loaded ? "yes" : "no",
            x.bond_db_readback==1 ? "MATCH" : x.bond_db_readback==2 ? "FAILED" : "N/A");
        printf("HCI local BD_ADDR=%02lx:%02lx:%02lx:%02lx:%02lx:%02lx verified=%s\n",
            (unsigned long)((x.bond_actual_bd_hi>>8)&255u),
            (unsigned long)(x.bond_actual_bd_hi&255u),
            (unsigned long)((x.bond_actual_bd_lo>>24)&255u),
            (unsigned long)((x.bond_actual_bd_lo>>16)&255u),
            (unsigned long)((x.bond_actual_bd_lo>>8)&255u),
            (unsigned long)(x.bond_actual_bd_lo&255u),
            x.bond_local_addr_match==1 ? "MATCH" :
            x.bond_local_addr_match==2 ? "MISMATCH" : "NOT READ");
        printf("Bond HCI: link requests=%lu positive replies=%lu reply failures=%lu negative replies=%lu\n",
            (unsigned long)x.bond_link_key_requests,
            (unsigned long)x.bond_key_reply_ok,
            (unsigned long)x.bond_key_reply_fail,
            (unsigned long)x.bond_key_negative);
        printf("Bond HCI: new key notifications=%lu last key type=%lu\n",
            (unsigned long)x.bond_key_notifications,
            (unsigned long)x.bond_last_new_key_type);
        printf("Bond HCI: ACL events=%lu status=%02lx auth events=%lu status=%02lx\n",
            (unsigned long)x.bond_acl_events, (unsigned long)x.bond_acl_status,
            (unsigned long)x.bond_auth_events, (unsigned long)x.bond_auth_status);
        printf("Bond HCI: encryption events=%lu status=%02lx enabled=%lu disconnect events=%lu reason=%02lx\n",
            (unsigned long)x.bond_encrypt_events, (unsigned long)x.bond_encrypt_status,
            (unsigned long)x.bond_encrypt_enabled,
            (unsigned long)x.bond_disconnect_events,
            (unsigned long)x.bond_disconnect_reason);
        if (!x.pair_requested)
            puts("Bootstrap mode: put device in pairing mode, run BTDiag --scan.");
        else if (x.a2dp_controller_working)
            puts("Run BTDiag --key after the first successful pairing.");
    }
    if (x.mode == 6 || x.mode == 7) {
        if(x.mode==7 && x.pair_requested){
            static const char *states[]={"idle","waiting","connecting","streaming","closing"};
            const char *rs=x.a2dp_reconnect_state<5 ? states[x.a2dp_reconnect_state]:"unknown";
            printf("Reconnect: %s attempts=%lu failures=%lu successes=%lu wait=%lu ms last=%02lx watchdogs=%lu stalled=%lu\n",
                   rs, (unsigned long)x.a2dp_reconnect_attempts,
                   (unsigned long)x.a2dp_reconnect_failures,
                   (unsigned long)x.a2dp_reconnect_successes,
                   (unsigned long)x.a2dp_reconnect_delay_ms,
                   (unsigned long)x.a2dp_reconnect_last_error,
                   (unsigned long)x.a2dp_reconnect_watchdogs,
                   (unsigned long)x.a2dp_reconnect_stalled);
        }
        printf("A2DP stack=%lu controller=%lu stream_open=%lu started=%lu\n",
            (unsigned long)x.a2dp_stack_started, (unsigned long)x.a2dp_controller_working,
            (unsigned long)x.a2dp_stream_open, (unsigned long)x.a2dp_stream_started);
        printf("A2DP SBC: rate=%lu packets=%lu frames=%lu elapsed=%lu ms status=%lu errors=%lu\n",
            (unsigned long)x.a2dp_sample_rate, (unsigned long)x.a2dp_packets,
            (unsigned long)x.a2dp_sbc_frames, (unsigned long)x.a2dp_elapsed_ms,
            (unsigned long)x.a2dp_last_status, (unsigned long)x.a2dp_transport_errors);
        printf("Media scheduler: ticks=%lu requests=%lu callbacks=%lu retries=%lu attempts=%lu\n",
            (unsigned long)x.a2dp_timer_ticks, (unsigned long)x.a2dp_send_requests,
            (unsigned long)x.a2dp_can_send_events, (unsigned long)x.a2dp_send_retries,
            (unsigned long)x.a2dp_send_attempts);
        printf("Media state: mtu=%lu SBCsamples=%lu SBCbytes=%lu skip=%lu send_rc=%lu\n",
            (unsigned long)x.a2dp_last_media_mtu,
            (unsigned long)x.a2dp_sbc_samples_per_frame,
            (unsigned long)x.a2dp_sbc_bytes_per_frame,
            (unsigned long)x.a2dp_last_skip_reason,
            (unsigned long)x.a2dp_last_send_rc);
        printf("SBC probe: first4=%08lx peak=%lu config: bitpool=%lu mode=%lu blocks=%lu bands=%lu\n",
            (unsigned long)x.a2dp_sbc_first4, (unsigned long)x.a2dp_pcm_peak,
            (unsigned long)x.a2dp_negotiated_bitpool,
            (unsigned long)x.a2dp_negotiated_mode,
            (unsigned long)x.a2dp_negotiated_blocks,
            (unsigned long)x.a2dp_negotiated_subbands);
        printf("HCI ACL: tx=%lu bytes=%lu completed=%lu completion_events=%lu rx=%lu\n",
            (unsigned long)x.a2dp_acl_tx_packets,
            (unsigned long)x.a2dp_acl_tx_bytes,
            (unsigned long)x.a2dp_acl_completed,
            (unsigned long)x.a2dp_acl_completion_events,
            (unsigned long)x.a2dp_acl_rx_packets);
        /* POC10: only transport telemetry. Secret key and command paths unchanged. */
        printf("HCI transport: aggregate=%lu RX UART error bytes=%lu H4 bad_type=%lu overflow=%lu oversize=%lu\n",
            (unsigned long)x.a2dp_transport_errors,
            (unsigned long)x.hci_rx_uart_error_bytes,
            (unsigned long)x.hci_rx_h4_bad_type,
            (unsigned long)x.hci_rx_h4_overflow,
            (unsigned long)x.hci_rx_h4_oversize);
        printf("PL011 RX flags: overrun=%lu break=%lu parity=%lu framing=%lu\n",
            (unsigned long)x.hci_rx_uart_overrun,
            (unsigned long)x.hci_rx_uart_break,
            (unsigned long)x.hci_rx_uart_parity,
            (unsigned long)x.hci_rx_uart_framing);
        printf("PL011 TX: FIFO_timeout=%lu BUSY_timeout=%lu partial=%lu last=%lu/%lu last_FR=%08lx\n",
            (unsigned long)x.hci_tx_fifo_timeouts,
            (unsigned long)x.hci_tx_busy_timeouts,
            (unsigned long)x.hci_tx_partial_timeouts,
            (unsigned long)x.hci_tx_last_fail_sent,
            (unsigned long)x.hci_tx_last_fail_total,
            (unsigned long)x.hci_tx_last_fail_fr);
        printf("Recovery: attempts=%lu HCI-ready=%lu failures=%lu stage=%lu last=%lu\n",
           (unsigned long)x.recover_attempts,(unsigned long)x.recover_successes,
           (unsigned long)x.recover_failures,(unsigned long)x.recover_stage,
           (unsigned long)x.recover_last_error);
    printf("PL011 live: CR=%08lx FR=%08lx CTS=%s IBRD=%lu FBRD=%lu\n",
            (unsigned long)x.hci_pl011_cr_live,
            (unsigned long)x.hci_pl011_fr_live,
            (x.hci_pl011_fr_live & 1u) ? "yes" : "no",
            (unsigned long)x.hci_pl011_ibrd_live,
            (unsigned long)x.hci_pl011_fbrd_live);
    }

    return (x.stop_reason == BTDIAG_STOP_OK ||
            x.stop_reason == BTDIAG_STOP_FW_SUCCESS ||
            x.stop_reason == BTDIAG_STOP_INQUIRY_OK ||
            x.stop_reason == BTDIAG_STOP_PAIR_SUCCESS ||
            x.stop_reason == BTDIAG_STOP_A2DP_TONE_COMPLETE) ? 0 : 5;
}