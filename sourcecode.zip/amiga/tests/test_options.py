#!/usr/bin/env python3
"""Host-only unit test for the exact PaulaMixer ToolType parser source.
No Amiga headers, no physical mailbox accesses.
"""
import pathlib, re, subprocess, tempfile
root=pathlib.Path(__file__).resolve().parents[1]
s=(root/'PaulaMixer.c').read_text()
chunk=s[s.index('static int same_ci'):s.index('static void hide_gui')]
code=r'''
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdint.h>
typedef unsigned long ULONG;
typedef signed char BYTE;
typedef char *STRPTR;
typedef const char *CONST_STRPTR;
static int config_overrides,onetime,popup=1;
static signed char broker_priority;
static char popup_key[100]="rawkey control alt m";
static int opt_master_set,opt_stereo_set,opt_interp_set;
static ULONG opt_master,opt_stereo,opt_interp;
static unsigned opt_mute_set,opt_mute_bits;
static char *mock_args[30];
static char *ArgString(const char *const *ignored, const char *key, const char *def) {
    (void)ignored;
    for(int i=0; mock_args[i]; ++i) {
       const char *p=mock_args[i], *q=key;
       while(*p && *q && toupper((unsigned char)*p)==toupper((unsigned char)*q)) { p++;q++; }
       if(!*q && *p=='=') return (char*)(p+1);
    }
    return (char*)def;
}
static void reset(void) {
  memset(mock_args,0,sizeof(mock_args));
  config_overrides=onetime=0;popup=1;broker_priority=0;
  opt_master_set=opt_stereo_set=opt_interp_set=0;
  opt_master=opt_stereo=opt_interp=0;
  opt_mute_set=opt_mute_bits=0;
  strcpy(popup_key,"rawkey control alt m");
}
'''
code+=chunk
code+=r'''
int main(void) {
   reset(); assert(parse_options((const char **)mock_args));
   assert(!config_overrides && !onetime && popup);
   reset(); mock_args[0]="CX_POPUP=NO"; mock_args[1]="MASTER=80";
   mock_args[2]="MUTE2=YES"; mock_args[3]="INTERPOLATION=LINEAR";
   mock_args[4]="ONESHOT=YES"; mock_args[5]="CX_PRIORITY=-128";
   assert(parse_options((const char **)mock_args));
   assert(!popup && onetime && broker_priority==-128);
   assert(opt_master_set && opt_master==80 && !opt_stereo_set);
   assert(opt_interp_set && opt_interp==1);
   assert(opt_mute_set==4 && opt_mute_bits==4);
   reset(); mock_args[0]="MUTE_MASK=15";mock_args[1]="MUTE3=NO";
   assert(parse_options((const char **)mock_args));
   assert(opt_mute_set==15 && opt_mute_bits==7);
   reset();mock_args[0]="MASTER=101";assert(!parse_options((const char **)mock_args));
   reset();mock_args[0]="STEREO=100";assert(parse_options((const char **)mock_args));
   reset();mock_args[0]="MUTE_MASK=16";assert(!parse_options((const char **)mock_args));
   reset();mock_args[0]="MUTE0=maybe";assert(!parse_options((const char **)mock_args));
   reset();mock_args[0]="CX_PRIORITY=128";assert(!parse_options((const char **)mock_args));
   reset();mock_args[0]="CX_POPKEY=rawkey control alt m";
   assert(parse_options((const char **)mock_args));
   assert(!strcmp(popup_key,"rawkey control alt m"));
   puts("Parser smoke tests: PASS");
   return 0;
}
'''
with tempfile.TemporaryDirectory() as d:
  c=pathlib.Path(d,'smoke.c');exe=pathlib.Path(d,'smoke')
  c.write_text(code)
  subprocess.run(['gcc','-std=c11','-O1','-Wall','-Wextra','-Werror',str(c),'-o',str(exe)],check=True)
  subprocess.run([str(exe)],check=True)
