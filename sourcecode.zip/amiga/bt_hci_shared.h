/* Paula-BT HCI POC6: temporary read-only Emu68 <-> M68k diagnostic ABI.
 * IMPORTANT: POC address is reserved ONLY by a kernel built with this module.
 * Do not access it with stock Emu68. Fields are big-endian 32-bit words on
 * both Emu68 AArch64-BE and Amiga m68k (no byte swaps).
 * SPDX-License-Identifier: MPL-2.0
 */
#ifndef EMU68_BT_HCI_SHARED_H
#define EMU68_BT_HCI_SHARED_H
#include <stdint.h>
#define BTDIAG_ADDRESS 0xFDE68000u
#define BTDIAG_MAGIC 0x42544447u  /* 'BTDG' */
#define BTDIAG_VERSION 13u
#define BTCTRL_ADDRESS (BTDIAG_ADDRESS + 0x1000u)
#define BTCTRL_MAGIC 0x42544338u  /* BTC8 */
#define BTCTRL_VERSION 1u
#define BTCTRL_SCAN 1u
#define BTCTRL_KEY 2u
#define BTCTRL_RECOVER 3u
#define BTCTRL_OK 1u
#define BTCTRL_NO_KEY 2u
#define BTCTRL_BAD_MODE 3u
#define BTCTRL_FAILED 4u
#define BTDIAG_STATE_WAIT 1u
#define BTDIAG_STATE_RUNNING 2u
#define BTDIAG_STATE_DONE 3u
#define BTDIAG_STOP_NONE 0u
#define BTDIAG_STOP_NO_CLOCK 1u
#define BTDIAG_STOP_BAD_GPCLK2 2u
#define BTDIAG_STOP_BAD_DIVISOR 3u
#define BTDIAG_STOP_NO_CTS 4u
#define BTDIAG_STOP_RESET_FAILED 5u
#define BTDIAG_STOP_VERSION_FAILED 6u
#define BTDIAG_STOP_OK 7u
#define BTDIAG_STOP_FW_NOT_BUILT 8u
#define BTDIAG_STOP_FW_UNEXPECTED_CHIP 9u
#define BTDIAG_STOP_FW_MINIDRV_FAILED 10u
#define BTDIAG_STOP_FW_RECORD_FAILED 11u
#define BTDIAG_STOP_FW_CORRUPT 12u
#define BTDIAG_STOP_FW_POSTRESET_FAILED 13u
#define BTDIAG_STOP_FW_POSTVERSION_FAILED 14u
#define BTDIAG_STOP_FW_SUCCESS 15u
#define BTDIAG_STOP_FW_BUDGET 16u
#define BTDIAG_STOP_BAD_ADDRESS 17u
#define BTDIAG_STOP_SET_ADDRESS_FAILED 18u
#define BTDIAG_STOP_BAUD_COMMAND_FAILED 19u
#define BTDIAG_STOP_BAUD_HOST_FAILED 20u
#define BTDIAG_STOP_BAUD_VERIFY_FAILED 21u
#define BTDIAG_STOP_INQUIRY_FAILED 22u
#define BTDIAG_STOP_INQUIRY_OK 23u
#define BTDIAG_STOP_PAIR_MISSING_ADDR 24u
#define BTDIAG_STOP_PAIR_BAD_PEER 25u
#define BTDIAG_STOP_PAIR_SETUP_FAILED 26u
#define BTDIAG_STOP_PAIR_CREATE_FAILED 27u
#define BTDIAG_STOP_PAIR_CONNECTION_FAILED 28u
#define BTDIAG_STOP_PAIR_AUTH_FAILED 29u
#define BTDIAG_STOP_PAIR_ENCRYPT_FAILED 30u
#define BTDIAG_STOP_PAIR_SUCCESS 31u
#define BTDIAG_STOP_PAIR_TIMEOUT 32u
#define BTDIAG_STOP_PAIR_EVENT_FAILED 33u
#define BTDIAG_STOP_PAIR_LEGACY_UNSUPPORTED 34u
#define BTDIAG_STOP_PAIR_NOT_BUILT 35u
#define BTDIAG_STOP_A2DP_INIT_FAILED 36u
#define BTDIAG_STOP_A2DP_CONNECT_FAILED 37u
#define BTDIAG_STOP_A2DP_TIMEOUT 38u
#define BTDIAG_STOP_A2DP_TONE_COMPLETE 39u
#define BTDIAG_STOP_A2DP_STREAM_FAILED 40u
#define BTDIAG_STOP_A2DP_PAULA_LIVE 41u
#define BTDIAG_STOP_BAD_BOND 42u
#define BTDIAG_STOP_A2DP_RECONNECTING 43u
#define BTDIAG_MAX_DEVICES 8u

/* Separate 4 KiB non-cacheable, user-writable command page.
 * request_seq is written LAST by Amiga; completed_seq written LAST by CPU3.
 * The 16-byte secret is produced only following explicit BTCTRL_KEY request;
 * applications must avoid copying it into ordinary diagnostic logs.
 */
struct bt_hci_control_shared {
    uint32_t magic, version, size;
    uint32_t command;
    uint32_t request_seq;
    uint32_t completed_seq;
    uint32_t result;
    uint32_t key_type;
    uint8_t  link_key[16];
    uint8_t  peer[6];
    uint8_t  reserved[2];
};
_Static_assert(sizeof(struct bt_hci_control_shared) <= 4096, "BT command ABI");

/* Simple fixed-width, BE-friendly diagnostics: only written by CPU3. */
struct bt_hci_scan_device {
    uint8_t address[6]; /* display order */
    int8_t rssi;
    uint8_t flags;      /* bit 0 = RSSI valid, bit 1 = name valid */
    uint32_t class_of_device;
    char name[40];
};

struct bt_hci_diag_shared {
    uint32_t magic;
    uint32_t version;
    uint32_t size;
    uint32_t state;           /* written last on completion */
    uint32_t mode;            /* 0 disabled, 1 diag, 2 probe */
    uint32_t cpu3_seen;
    uint32_t fsel3;
    uint32_t fsel4;
    uint32_t gp2ctl;
    uint32_t gp2div;
    uint32_t uart_cr;
    uint32_t uart_fr;
    uint32_t uart_clock_hz;
    uint32_t uart_ibrd;
    uint32_t uart_fbrd;
    uint32_t uart_fr_active;
    uint32_t cts_seen;
    uint32_t rx_discarded;
    uint32_t stop_reason;
    int32_t  reset_rc;
    uint32_t reset_len;
    uint32_t reset_status;
    int32_t  version_rc;
    uint32_t version_len;
    uint32_t version_status;
    uint32_t hci_version;
    uint32_t hci_revision;
    uint32_t lmp_version;
    uint32_t manufacturer;
    uint32_t lmp_subversion;
    uint32_t uart_restored;
    /* POC3 extension; never change POC2 prefix above. */
    uint32_t fw_image_bytes;
    uint32_t fw_records_total;
    uint32_t fw_records_sent;
    uint32_t fw_failed_opcode;
    uint32_t fw_failed_offset;
    int32_t  fw_command_rc;
    uint32_t fw_command_status;
    uint32_t post_hci_version;
    uint32_t post_hci_revision;
    uint32_t post_lmp_version;
    uint32_t post_manufacturer;
    uint32_t post_lmp_subversion;
    uint32_t bd_addr_valid;
    uint32_t bd_addr_hi; /* first two address bytes in display order */
    uint32_t bd_addr_lo; /* final four address bytes in display order */
    /* POC4 extension, POC3 prefix preserved. */
    uint32_t uart_owned;
    uint32_t scan_uart_baud;
    uint32_t baud_verified;
    uint32_t address_config_state; /* 0=unset,1=requested,2=applied,3=invalid */
    uint32_t scan_mode;
    uint32_t scan_count;
    uint32_t scan_complete;
    int32_t  scan_rc;
    struct bt_hci_scan_device devices[BTDIAG_MAX_DEVICES];
    /* POC5 extension. No raw link key in the read-only diagnostic page. */
    uint8_t pair_peer[6];         /* display order */
    uint8_t pair_reserved[2];
    uint32_t pair_requested;      /* 1 when explicit bt_peer= supplied */
    uint32_t pair_acl_connected;
    uint32_t pair_authenticated;
    uint32_t pair_encrypted;
    uint32_t pair_ssp_complete;
    uint32_t pair_link_key_seen;  /* key retained only in private ARM RAM */
    uint32_t pair_disconnected;
    uint32_t pair_handle;
    uint32_t pair_last_event;
    uint32_t pair_last_opcode;
    uint32_t pair_last_status;
    uint32_t pair_connection_status;
    uint32_t pair_auth_status;
    uint32_t pair_encryption_status;
    uint32_t pair_disconnect_status;
    uint32_t pair_io_capability_requests;
    uint32_t pair_confirmation_requests;
    uint32_t pair_legacy_pin_requests;
    uint32_t pair_key_requests;
    uint32_t pair_elapsed_ms;
    /* POC6 extension: counters never contain pairing keys or PCM samples. */
    uint32_t a2dp_stack_started;
    uint32_t a2dp_controller_working;
    uint32_t a2dp_stream_open;
    uint32_t a2dp_stream_started;
    uint32_t a2dp_sample_rate;
    uint32_t a2dp_sbc_frames;
    uint32_t a2dp_packets;
    uint32_t a2dp_elapsed_ms;
    uint32_t a2dp_transport_errors;
    uint32_t a2dp_last_status;
    /* POC6 FIX2: instruments A2DP media scheduling, no link keys or audio. */
    uint32_t a2dp_timer_ticks;
    uint32_t a2dp_send_requests;
    uint32_t a2dp_can_send_events;
    uint32_t a2dp_send_attempts;
    uint32_t a2dp_send_retries;
    uint32_t a2dp_last_skip_reason;
    uint32_t a2dp_last_media_mtu;
    uint32_t a2dp_sbc_samples_per_frame;
    uint32_t a2dp_sbc_bytes_per_frame;
    uint32_t a2dp_last_send_rc;
    /* FIX4: passive media evidence, no keys or PCM copied to Amiga memory. */
    uint32_t a2dp_sbc_first4;       /* raw SBC sync/header/bitpool/CRC */
    uint32_t a2dp_pcm_peak;         /* absolute peak of generated samples */
    uint32_t a2dp_negotiated_bitpool;
    uint32_t a2dp_negotiated_mode;
    uint32_t a2dp_negotiated_blocks;
    uint32_t a2dp_negotiated_subbands;
    uint32_t a2dp_acl_tx_packets;   /* H4 ACL packets queued to UART */
    uint32_t a2dp_acl_tx_bytes;
    uint32_t a2dp_acl_completed;    /* HCI Number Of Completed Packets events */
    uint32_t a2dp_acl_completion_events;
    uint32_t a2dp_acl_rx_packets;
    /* POC7 extension: ARM-only live Paula counters; no audio samples exposed. */
    uint32_t paula_pcm_produced;
    uint32_t paula_pcm_consumed;
    uint32_t paula_ring_fill;
    uint32_t paula_underruns;
    uint32_t paula_overruns;
    uint32_t paula_pcm_peak;
    uint32_t paula_nonzero_frames;
    uint32_t paula_capture_drops;
    uint32_t paula_cache_misses;
    /* POC8 appended fields: preserve prior read-only prefix. */
    uint32_t bd_addr_source;    /* 0 none; 1 override, 2 device tree */
    uint32_t bond_configured;
    uint32_t bond_loaded;
    /* POC8 BOND-DIAG FIX1: authentication telemetry, NO SECRET KEY BYTES. */
    uint32_t bond_db_readback;       /* 0 no bond; 1 exact key/type in DB; 2 mismatch */
    uint32_t bond_local_addr_match;  /* 0 not read; 1 expected; 2 mismatch */
    uint32_t bond_actual_bd_hi;      /* first 2 bytes, display order */
    uint32_t bond_actual_bd_lo;      /* last 4 bytes, display order */
    uint32_t bond_link_key_requests; /* HCI peer requests stored key */
    uint32_t bond_key_reply_ok;      /* controller accepted positive HCI command */
    uint32_t bond_key_reply_fail;    /* controller rejected positive HCI command */
    uint32_t bond_key_negative;      /* HCI negative reply command completed */
    uint32_t bond_key_notifications; /* new bond generated (possible replacement) */
    uint32_t bond_last_new_key_type; /* only key type; NOT the key */
    uint32_t bond_acl_events;
    uint32_t bond_acl_status;        /* 0xff = not seen */
    uint32_t bond_auth_events;
    uint32_t bond_auth_status;       /* 0xff = not seen */
    uint32_t bond_encrypt_events;
    uint32_t bond_encrypt_status;    /* 0xff = not seen */
    uint32_t bond_encrypt_enabled;
    uint32_t bond_disconnect_events;
    uint32_t bond_disconnect_reason;/* 0xff = not seen */
    /* POC9 appended fields: current recovery state, no secrets. */
    uint32_t a2dp_reconnect_state;   /* 0 idle,1 wait,2 connect,3 stream,4 close */
    uint32_t a2dp_reconnect_attempts;
    uint32_t a2dp_reconnect_failures;
    uint32_t a2dp_reconnect_successes;
    uint32_t a2dp_reconnect_delay_ms;
    uint32_t a2dp_reconnect_last_error;
    uint32_t a2dp_reconnect_watchdogs;
    uint32_t a2dp_reconnect_stalled; /* 1=AVDTP teardown has not completed */
    /* POC10 diagnostic-only extension; POC9 FIX2 fields above unchanged.
     * All counts are cumulative since CPU3 started; no HCI/PCM payloads.
     * Each UART error byte contributes once to the legacy error total,
     * but may increment multiple PL011 DR error-bit counters.
     */
    uint32_t hci_rx_uart_error_bytes;
    uint32_t hci_rx_uart_overrun;
    uint32_t hci_rx_uart_break;
    uint32_t hci_rx_uart_parity;
    uint32_t hci_rx_uart_framing;
    uint32_t hci_rx_h4_bad_type;
    uint32_t hci_rx_h4_overflow;
    uint32_t hci_rx_h4_oversize;
    uint32_t hci_tx_fifo_timeouts;
    uint32_t hci_tx_busy_timeouts;
    uint32_t hci_tx_partial_timeouts;
    uint32_t hci_tx_last_fail_sent;  /* H4 type byte + payload bytes queued */
    uint32_t hci_tx_last_fail_total; /* H4 type byte + payload size */
    uint32_t hci_tx_last_fail_fr;    /* flag register at last TX timeout */
    uint32_t hci_pl011_cr_live;
    uint32_t hci_pl011_fr_live;
    uint32_t hci_pl011_ibrd_live;
    uint32_t hci_pl011_fbrd_live;
    /* POC11-B: manual, BT-only rebootstrap, no SDIO/power control. */
    uint32_t recover_attempts;
    uint32_t recover_successes; /* HCI WORKING, NOT necessarily audio playing */
    uint32_t recover_failures;
    uint32_t recover_stage;     /* 0 idle,1 quiesce,2 hardware,3 BTstack,4 ready,5 failed */
    uint32_t recover_last_error;/* BTDIAG_STOP_*, never key material */
};
_Static_assert(sizeof(struct bt_hci_scan_device) == 52, "scan ABI");
_Static_assert(sizeof(struct bt_hci_diag_shared) <= 4096, "diagnostic page ABI");
#endif
